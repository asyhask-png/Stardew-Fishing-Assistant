﻿# Fishing Assistant — сборка, тесты и упаковка в один шаг.
# Использование: powershell -File package.ps1 [-GamePath "C:\Games\Stardew Valley"]
param(
    [string]$GamePath = "c:\steam\steamapps\common\Stardew Valley"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dotnet = Join-Path $env:LOCALAPPDATA "Temp\opencode\dotnet-sdk\dotnet.exe"
if (-not (Test-Path $dotnet)) { $dotnet = "dotnet" }  # системный SDK

$srcProj = Join-Path $root "src\FishingAssistant\FishingAssistant.csproj"
$tests   = Join-Path $root "tests\FishingAssistant.Tests\FishingAssistant.Tests.csproj"
$dist    = Join-Path $root "dist"
$pkgName = "FishingAssistant"
$pkgDir  = Join-Path $dist $pkgName
$zip     = Join-Path $dist "FishingAssistant-1.0.0.zip"

Write-Host "== 1. Сборка мода =="
& $dotnet build $srcProj -c Release --nologo "-p:GamePath=$GamePath"
if ($LASTEXITCODE -ne 0) { throw "build failed" }

Write-Host "`n== 2. Тесты чистых алгоритмов =="
& $dotnet run --project $tests -c Release "--property:GamePath=$GamePath"
if ($LASTEXITCODE -ne 0) { throw "tests failed" }

Write-Host "`n== 3. Формирование папки мода =="
$bin = Join-Path $root "src\FishingAssistant\bin\Release"
if (Test-Path $pkgDir) { Remove-Item $pkgDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $pkgDir | Out-Null
Copy-Item (Join-Path $bin "FishingAssistant.dll") $pkgDir
Copy-Item (Join-Path $bin "manifest.json")        $pkgDir
Copy-Item (Join-Path $bin "i18n")                 $pkgDir -Recurse
Copy-Item (Join-Path $root "README.md")           $pkgDir

Write-Host "`n== 4. ZIP-архив =="
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path $pkgDir -DestinationPath $zip

Write-Host "`n== 5. Установка в Mods =="
$modsDir = Join-Path $GamePath "Mods\$pkgName"
try {
    if (Test-Path $modsDir) { Remove-Item $modsDir -Recurse -Force }
    Copy-Item $pkgDir $modsDir -Recurse
    Write-Host "Установлено: $modsDir"
} catch {
    Write-Warning "Не удалось скопировать в Mods (запущена игра?): скопируйте вручную из $pkgDir"
}

Write-Host "`nГотово:"
Get-ChildItem $pkgDir | Select-Object Name, Length
Write-Host "ZIP: $zip"
