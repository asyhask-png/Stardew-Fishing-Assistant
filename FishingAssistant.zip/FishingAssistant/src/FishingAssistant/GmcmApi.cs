using System;
using StardewModdingAPI;
using StardewModdingAPI.Events;

namespace FishingAssistant
{
    /// <summary>Минимальное описание API Generic Mod Config Menu (spacechase0).</summary>
    /// <remarks>Определено локально; сам GMCM не требуется для работы мода.</remarks>
    public interface IGenericModConfigMenuApi
    {
        /// <summary>Регистрирует меню настроек мода.</summary>
        void Register(IManifest mod, Action reset, Action save, bool resetButtonVisible = true);

        /// <summary>Убирает регистрацию мода.</summary>
        void Unregister(IManifest mod);

        /// <summary>Добавляет логическую опцию.</summary>
        void AddBoolOption(IManifest mod, Func<bool> getValue, Action<bool> setValue, Func<string> name, Func<string> tooltip = null, string fieldId = null);

        /// <summary>Добавляет числовую опцию.</summary>
        void AddNumberOption(IManifest mod, Func<int> getValue, Action<int> setValue, Func<string> name, Func<string> tooltip = null, int? min = null, int? max = null, int? interval = null, Func<int, string> formatValue = null, string fieldId = null);

        /// <summary>Добавляет числовую опцию с плавающей точкой.</summary>
        void AddNumberOption(IManifest mod, Func<float> getValue, Action<float> setValue, Func<string> name, Func<string> tooltip = null, float? min = null, float? max = null, float? interval = null, Func<float, string> formatValue = null, string fieldId = null);

        /// <summary>Добавляет текстовую опцию.</summary>
        void AddTextOption(IManifest mod, Func<string> getValue, Action<string> setValue, Func<string> name, Func<string> tooltip = null, string[] allowedValues = null, Func<string, string> formatAllowedValue = null, string fieldId = null);

        /// <summary>Добавляет привязку клавиши.</summary>
        void AddKeybind(IManifest mod, Func<SButton> getValue, Action<SButton> setValue, Func<string> name, Func<string> tooltip = null, string fieldId = null);

        /// <summary>Добавляет заголовок секции.</summary>
        void AddSectionTitle(IManifest mod, Func<string> text, Func<string> tooltip = null);

        /// <summary>Добавляет абзац текста.</summary>
        void AddParagraph(IManifest mod, Func<string> text, Func<string> tooltip = null);

        /// <summary>Подписывается на изменение полей.</summary>
        void OnFieldChanged(IManifest mod, Action<string, object> onChange);
    }
}
