using System;

namespace FishingAssistant.Pure
{
    /// <summary>Тип специальной рыболовной точки.</summary>
    [Flags]
    public enum BubbleKind
    {
        /// <summary>Обычные пузырьки.</summary>
        Splash = 1,
        /// <summary>Рыбный угар (Fish Frenzy), увеличенный радиус поклёвки.</summary>
        FishFrenzy = 2,
    }

    /// <summary>Обнаруженное пузырьковое место (чистая модель без ссылок на игру).</summary>
    public class BubbleTarget : IEquatable<BubbleTarget>
    {
        /// <summary>Имя игровой локации.</summary>
        public string LocationName { get; }

        /// <summary>X клетки пузырьков.</summary>
        public int X { get; }

        /// <summary>Y клетки пузырьков.</summary>
        public int Y { get; }

        /// <summary>Тип точки.</summary>
        public BubbleKind Kind { get; }

        /// <summary>Момент первого обнаружения (мс среды).</summary>
        public long FirstSeenMs { get; }

        /// <summary>Момент последнего подтверждения (мс среды).</summary>
        public long LastSeenMs { get; set; }

        /// <summary>Стабильный ключ для сравнения и дедупликации уведомлений.</summary>
        public string Key => $"{LocationName}|{X}|{Y}|{Kind}";

        /// <summary>Создаёт описание пузырькового места.</summary>
        public BubbleTarget(string locationName, int x, int y, BubbleKind kind, long nowMs)
        {
            LocationName = locationName;
            X = x;
            Y = y;
            Kind = kind;
            FirstSeenMs = nowMs;
            LastSeenMs = nowMs;
        }

        /// <inheritdoc/>
        public bool Equals(BubbleTarget other) => other != null && Key == other.Key;

        /// <inheritdoc/>
        public override bool Equals(object obj) => Equals(obj as BubbleTarget);

        /// <inheritdoc/>
        public override int GetHashCode() => Key.GetHashCode();

        /// <inheritdoc/>
        public override string ToString() => $"{LocationName} ({X},{Y}) [{Kind}]";
    }
}
