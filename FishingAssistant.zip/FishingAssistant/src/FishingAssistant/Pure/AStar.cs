using System;
using System.Collections.Generic;

namespace FishingAssistant.Pure
{
    /// <summary>Проверка проходимости клетки. Возвращает true, если по клетке можно идти.</summary>
    public delegate bool PassabilityPredicate(int x, int y);

    /// <summary>Поиск пути A* по клеткам (4 направления, диагонали с проверкой углов).</summary>
    public static class AStar
    {
        /// <summary>Максимальное число раскрытых узлов — защита от зависаний на огромных картах.</summary>
        public const int MaxExpansions = 30000;

        private struct Node
        {
            public int X, Y;
            public float G, F;
        }

        /// <summary>
        /// Ищет путь от start к goal. Диагональные шаги разрешены только при свободных обоих соседних ортогональных клетках.
        /// </summary>
        /// <param name="inBounds">Границы карты: true, если клетка существует.</param>
        /// <param name="passable">Проходимость клетки.</param>
        /// <param name="start">Начальная клетка.</param>
        /// <param name="goal">Целевая клетка.</param>
        /// <param name="allowDiagonals">Разрешить диагональные шаги.</param>
        /// <returns>Список клеток от start до goal включительно либо null.</returns>
        public static List<(int x, int y)> FindPath(
            PassabilityPredicate inBounds,
            PassabilityPredicate passable,
            (int x, int y) start,
            (int x, int y) goal,
            bool allowDiagonals = true)
        {
            if (start == goal)
                return new List<(int x, int y)> { start };
            if (!inBounds(goal.x, goal.y))
                return null;

            // Цель может быть непроходима (например, тайл двери-объекта): разрешаем финишировать рядом.
            bool goalPassable = passable(goal.x, goal.y);

            var open = new List<Node>();
            var gScore = new Dictionary<long, float>(1024);
            var cameFrom = new Dictionary<long, long>(1024);
            var closed = new HashSet<long>();

            long Key(int x, int y) => ((long)x << 32) ^ (uint)y;
            float H(int x, int y)
            {
                int dx = Math.Abs(x - goal.x), dy = Math.Abs(y - goal.y);
                return Math.Max(dx, dy) + 0.41f * Math.Min(dx, dy); // октильная эвристика
            }

            var sk = Key(start.x, start.y);
            open.Add(new Node { X = start.x, Y = start.y, G = 0, F = H(start.x, start.y) });
            gScore[sk] = 0;

            int expansions = 0;
            while (open.Count > 0)
            {
                if (++expansions > MaxExpansions)
                    return null;

                // достаём узел с минимальным F
                int bestIdx = 0;
                for (int i = 1; i < open.Count; i++)
                    if (open[i].F < open[bestIdx].F) bestIdx = i;
                var cur = open[bestIdx];
                open.RemoveAt(bestIdx);

                var ck = Key(cur.X, cur.Y);
                if (!closed.Add(ck))
                    continue;

                if (cur.X == goal.x && cur.Y == goal.y)
                {
                    // восстановление пути
                    var path = new List<(int x, int y)> { (cur.X, cur.Y) };
                    long k = ck;
                    while (cameFrom.TryGetValue(k, out long prev))
                    {
                        path.Add(((int)(prev >> 32), (int)prev));
                        k = prev;
                    }
                    path.Reverse();
                    return path;
                }

                for (int dx = -1; dx <= 1; dx++)
                {
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        if (dx == 0 && dy == 0) continue;
                        if (!allowDiagonals && dx != 0 && dy != 0) continue;

                        int nx = cur.X + dx, ny = cur.Y + dy;
                        if (!inBounds(nx, ny)) continue;
                        if (!passable(nx, ny)) continue;

                        if (dx != 0 && dy != 0)
                        {
                            // запрет срезания углов через стены
                            if (!passable(cur.X + dx, cur.Y) || !passable(cur.X, cur.Y + dy))
                                continue;
                        }

                        float step = (dx != 0 && dy != 0) ? 1.4142f : 1f;
                        float ng = gScore[ck] + step;
                        long nk = Key(nx, ny);
                        if (gScore.TryGetValue(nk, out float oldG) && oldG <= ng)
                            continue;

                        gScore[nk] = ng;
                        cameFrom[nk] = ck;
                        open.Add(new Node { X = nx, Y = ny, G = ng, F = ng + H(nx, ny) });
                    }
                }
            }
            return null;
        }

        /// <summary>Длина маршрута в тайлах (сумма шагов).</summary>
        public static float PathLength(List<(int x, int y)> path)
        {
            if (path == null || path.Count < 2) return 0f;
            float len = 0;
            for (int i = 1; i < path.Count; i++)
            {
                int dx = Math.Abs(path[i].x - path[i - 1].x);
                int dy = Math.Abs(path[i].y - path[i - 1].y);
                len += (dx == 1 && dy == 1) ? 1.4142f : 1f;
            }
            return len;
        }
    }
}
