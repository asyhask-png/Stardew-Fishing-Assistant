namespace FishingAssistant.Pure
{
    /// <summary>Снимок состояния мини-игры, достаточный для решений (чистая структура).</summary>
    public struct MinigameSnapshot
    {
        /// <summary>Позиция рыбы по шкале.</summary>
        public float FishPos;

        /// <summary>Центр планки по шкале.</summary>
        public float BarCenter;

        /// <summary>Половина высоты планки.</summary>
        public float BarHalf;

        /// <summary>Скорость планки (px/тик, положительная — вниз).</summary>
        public float BarSpeed;

        /// <summary>Прогресс поимки 0..1.</summary>
        public float Progress;

        /// <summary>Есть ли сундук с сокровищем на шкале.</summary>
        public bool TreasurePresent;

        /// <summary>Позиция сундука по шкале.</summary>
        public float TreasurePos;

        /// <summary>Заполнена ли шкала сокровища.</summary>
        public bool TreasureCaught;

        /// <summary>Прогресс сбора сундука 0..1.</summary>
        public float TreasureProgress;

        /// <summary>Рыба сейчас внутри планки.</summary>
        public bool FishInBar;
    }

    /// <summary>Решение управления планкой.</summary>
    public enum MinigameGoal { HoldFish, ChaseTreasure }

    /// <summary>
    /// Чистая модель приоритета «рыба против сундука».
    /// Рыба всегда важнее: переключение возможно только при запасе прогресса и стабильном удержании рыбы.
    /// </summary>
    public static class TreasureRiskModel
    {
        /// <summary>Минимальный запас прогресса для SafeOnly-переключения.</summary>
        public const float SafeMinProgress = 0.40f;

        /// <summary>Критический прогресс, при котором возвращаемся к рыбе всегда.</summary>
        public const float CriticalProgress = 0.15f;

        /// <summary>Максимальное расстояние рыба—центр планки, при котором считаем удержание безопасным.</summary>
        public const float SafeFishMarginPx = 26f;

        /// <summary>Выбирает цель управления.</summary>
        /// <param name="s">Снимок состояния.</param>
        /// <param name="mode">Режим из конфигурации.</param>
        /// <param name="currentlyChasing">Идёт ли уже сбор сундука.</param>
        public static MinigameGoal Decide(MinigameSnapshot s, TreasureMode mode, bool currentlyChasing)
        {
            if (mode == TreasureMode.Off || !s.TreasurePresent || s.TreasureCaught)
                return MinigameGoal.HoldFish;

            // Сундук собран — вернуться к рыбе немедленно.
            if (currentlyChasing && s.TreasureCaught)
                return MinigameGoal.HoldFish;

            float fishError = Abs(s.FishPos - s.BarCenter);
            bool fishStable = fishError <= s.BarHalf * 0.5f;      // рыба в середине планки
            bool fishSafe = fishError <= SafeFishMarginPx;

            switch (mode)
            {
                case TreasureMode.AlwaysTry:
                    if (s.Progress <= CriticalProgress)
                        return MinigameGoal.HoldFish;          // сначала не теряем рыбу
                    return MinigameGoal.ChaseTreasure;

                case TreasureMode.SafeOnly:
                default:
                    if (s.Progress >= SafeMinProgress && fishStable)
                        return MinigameGoal.ChaseTreasure;
                    return MinigameGoal.HoldFish;
            }
        }

        /// <summary>Достаточно ли безопасно продолжать погоню за сундуком прямо сейчас.</summary>
        public static bool ShouldAbortChase(MinigameSnapshot s, TreasureMode mode)
        {
            if (!s.TreasurePresent) return true;
            if (s.TreasureCaught) return false;
            if (mode == TreasureMode.AlwaysTry)
            {
                // при AlwaysTry прерываем только при критическом риске потери рыбы
                float projected = s.Progress - 0.003f * 30f;   // ~полсекунды вне зоны
                return projected <= 0f;
            }
            float fishError = Abs(s.FishPos - s.BarCenter);
            return !s.FishInBar || fishError > SafeFishMarginPx;
        }

        private static float Abs(float v) => v < 0 ? -v : v;
    }

    /// <summary>
    /// Чистый регулятор планки: bang-bang с мёртвой зоной и предсказанием торможения.
    /// Возвращает ускорение, которое нужно добавить к скорости планки (эквивалент нажатой кнопки).
    /// </summary>
    public static class BarController
    {
        /// <summary>Стандартное ускорение кнопки в игре (px/тик²).</summary>
        public const float ButtonAccel = 0.25f;

        /// <summary>Стандартная гравитация (px/тик²).</summary>
        public const float Gravity = 0.25f;

        /// <summary>Вычисляет желаемое ускорение к цели.</summary>
        /// <param name="barCenter">Текущий центр планки.</param>
        /// <param name="barSpeed">Текущая скорость планки.</param>
        /// <param name="target">Желаемое положение центра.</param>
        /// <param name="tolerancePx">Мёртвая зона.</param>
        /// <param name="strength">Интенсивность 0.2..2.</param>
        /// <param name="anticipate">Учитывать инерцию (тормозить заранее).</param>
        /// <returns>Добавка к скорости за тик (отрицательная = вверх).</returns>
        public static float ComputeAcceleration(
            float barCenter, float barSpeed, float target,
            float tolerancePx, float strength, bool anticipate)
        {
            float error = barCenter - target;              // >0: планка ниже цели → нужно вверх
            if (Abs(error) <= tolerancePx)
            {
                // в мёртвой зоне гасим остаточную скорость, чтобы не болтаться
                if (anticipate && Abs(barSpeed) > 0.05f)
                    return barSpeed > 0 ? -ButtonAccel : +ButtonAccel;
                return 0f;
            }

            bool wantUp = error > 0;
            float accel = wantUp ? -ButtonAccel : +ButtonAccel;
            accel *= Clamp(strength, 0.2f, 2f);

            if (anticipate)
            {
                // предсказание: остановимся ли до цели при текущей скорости?
                float stopDist = (barSpeed * barSpeed) / (2f * ButtonAccel * Clamp(strength, 0.2f, 2f));
                bool movingTowardTarget = (wantUp && barSpeed < 0) || (!wantUp && barSpeed > 0);
                if (movingTowardTarget && Abs(error) < stopDist * 1.1f)
                    return 0f;                             // отпускаем — долетит по инерции
            }
            return accel;
        }

        private static float Abs(float v) => v < 0 ? -v : v;

        private static float Clamp(float v, float lo, float hi) => v < lo ? lo : (v > hi ? hi : v);
    }
}
