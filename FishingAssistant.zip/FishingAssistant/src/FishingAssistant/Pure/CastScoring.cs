using System;
using System.Collections.Generic;

namespace FishingAssistant.Pure
{
    /// <summary>Кандидат заброса (чистая структура для выбора и тестов).</summary>
    public struct CastCandidate
    {
        /// <summary>Клетка, на которой стоит игрок.</summary>
        public int StandX, StandY;

        /// <summary>Клетка воды, куда упадёт поплавок.</summary>
        public int LandingX, LandingY;

        /// <summary>Направление взгляда: 0 вверх, 1 вправо, 2 вниз, 3 влево.</summary>
        public int Facing;

        /// <summary>Требуемая сила заброса 0..1.</summary>
        public float Power;

        /// <summary>Попадание точно в целевую клетку (пузырьки).</summary>
        public bool ExactHit;

        /// <summary>Расстояние от игрока до точки падения в тайлах.</summary>
        public float DistTiles;

        /// <summary>Расстояние от точки падения до цели (пузырьков), тайлов; 0 при точном попадании.</summary>
        public float MissTiles;
    }

    /// <summary>Чистая оценка кандидатов заброса. Вынесена отдельно для тестов.</summary>
    public static class CastScoring
    {
        /// <summary>
        /// Возвращает лучший кандидат: точное попадание важнее всего, затем близость к пузырькам,
        /// затем короткий путь игрока и запас силы.
        /// </summary>
        /// <param name="candidates">Кандидаты.</param>
        /// <param name="preferExact">Требовать точного попадания (есть пузырьки).</param>
        /// <returns>Лучший кандидат или null, если список пуст.</returns>
        public static CastCandidate? Best(IEnumerable<CastCandidate> candidates, bool preferExact)
        {
            if (candidates == null) return null;
            CastCandidate? best = null;
            double bestScore = double.MinValue;

            foreach (var c in candidates)
            {
                // штрафы: промах по пузырькам доминирует
                double score = -c.MissTiles * 1000.0
                               + (c.ExactHit && preferExact ? 500.0 : 0.0)
                               - c.DistTiles * 2.0
                               - Math.Abs(c.Power - 0.75f);      // приятный запас силы
                if (score > bestScore)
                {
                    bestScore = score;
                    best = c;
                }
            }
            return best;
        }

        /// <summary>Формула максимальной дальности заброса в тайлах (подтверждена дизассемблированием 1.6.15).</summary>
        public static int MaxCastTiles(int fishingLevel)
        {
            int added = fishingLevel >= 15 ? 4 : fishingLevel >= 8 ? 3 : fishingLevel >= 4 ? 2 : fishingLevel >= 1 ? 1 : 0;
            return added + 4;
        }

        /// <summary>Сила, необходимая для полёта на distTiles тайлов.</summary>
        public static float PowerForDistance(float distTiles, int maxTiles)
        {
            if (maxTiles <= 0) return 1f;
            return Clamp(distTiles / maxTiles, 0.08f, 1f);
        }

        private static float Clamp(float v, float lo, float hi) => v < lo ? lo : (v > hi ? hi : v);
    }
}
