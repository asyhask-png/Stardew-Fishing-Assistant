using System;
using System.Collections.Generic;
using System.Linq;

namespace FishingAssistant.Pure
{
    /// <summary>Информация о пойманном предмете, достаточная для фильтрации.</summary>
    public class CatchInfo
    {
        /// <summary>ID предмета без квалификатора, например "129".</summary>
        public string ItemId;

        /// <summary>Квалифицированный ID, например "(O)129".</summary>
        public string QualifiedItemId;

        /// <summary>Отображаемое название.</summary>
        public string DisplayName;

        /// <summary>Категория предмета (-4 рыба, -20 квестовые и т.п.).</summary>
        public int Category;

        /// <summary>Качество: 0 обычное, 1 серебро, 2 золото, 4 иридий.</summary>
        public int Quality;

        /// <summary>Это точно рыба (категория -4 или есть в Data/Fish).</summary>
        public bool IsFish;

        /// <summary>Легендарная рыба (встроенная защита).</summary>
        public bool IsLegendary;

        /// <summary>Квестовый/особый предмет (встроенная защита).</summary>
        public bool IsQuestOrSpecial;

        /// <summary>Предмет нельзя выбросить по правилам игры (встроенная защита).</summary>
        public bool CannotBeTrashed;

        /// <summary>Предмет пришёл из сундука с сокровищем этой рыбалки.</summary>
        public bool FromTreasure;

        /// <summary>Тип не удалось определить уверенно (встроенная защита).</summary>
        public bool UnknownType;
    }

    /// <summary>Решение фильтра.</summary>
    public enum FilterDecisionKind { Keep, Trash, ProtectedKeep }

    /// <summary>Результат проверки улова.</summary>
    public struct FilterDecision
    {
        /// <summary>Что делать с предметом.</summary>
        public FilterDecisionKind Kind;

        /// <summary>Причина (для уведомления и журнала).</summary>
        public string Reason;

        /// <summary>Создаёт решение.</summary>
        public static FilterDecision Make(FilterDecisionKind kind, string reason)
            => new FilterDecision { Kind = kind, Reason = reason ?? "" };
    }

    /// <summary>Параметры фильтра, снятые с конфигурации (чистые).</summary>
    public class FilterSettings
    {
        /// <summary>Режим: Off/Whitelist/Blacklist.</summary>
        public FishFilterMode Mode = FishFilterMode.Off;

        /// <summary>Минимальное качество (значения как в игре: 0/1/2/4).</summary>
        public int MinQuality;

        /// <summary>Максимальное качество.</summary>
        public int MaxQuality = 4;

        /// <summary>Нормализованные ключи белого списка (id или lowercase-названия).</summary>
        public HashSet<string> Allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>Нормализованные ключи чёрного списка.</summary>
        public HashSet<string> Blocked = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>Нормализованные ключи пользовательской защиты.</summary>
        public HashSet<string> Protected = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>Встроенные легендарные квалифицированные ID.</summary>
        public static readonly HashSet<string> LegendaryQids = new HashSet<string>
        {
            "(O)159", "(O)160", "(O)163", "(O)682", "(O)775",
            "(O)898", "(O)899", "(O)900", "(O)901",
        };
    }

    /// <summary>
    /// Чистый движок правил фильтра улова. Встроенные защиты имеют высший приоритет:
    /// легендарная рыба и квестовые предметы никогда не удаляются.
    /// </summary>
    public static class CatchRuleSet
    {
        /// <summary>Проверяет улов по правилам.</summary>
        public static FilterDecision Evaluate(CatchInfo item, FilterSettings s)
        {
            if (item == null || s == null)
                return FilterDecision.Make(FilterDecisionKind.ProtectedKeep, "null");

            // --- Встроенные защиты (не отключаются) ---
            if (item.FromTreasure)
                return FilterDecision.Make(FilterDecisionKind.ProtectedKeep, "treasure");
            if (item.UnknownType)
                return FilterDecision.Make(FilterDecisionKind.ProtectedKeep, "unknown-type");
            if (item.CannotBeTrashed)
                return FilterDecision.Make(FilterDecisionKind.ProtectedKeep, "cannot-be-trashed");
            if (item.IsLegendary || (item.QualifiedItemId != null && FilterSettings.LegendaryQids.Contains(item.QualifiedItemId)))
                return FilterDecision.Make(FilterDecisionKind.ProtectedKeep, "legendary");
            if (item.IsQuestOrSpecial || item.Category == -20)
                return FilterDecision.Make(FilterDecisionKind.ProtectedKeep, "quest");
            if (!item.IsFish && !HasExplicitRule(item, s))
                return FilterDecision.Make(FilterDecisionKind.ProtectedKeep, "not-fish-no-rule");

            if (s.Mode == FishFilterMode.Off)
                return FilterDecision.Make(FilterDecisionKind.Keep, "filter-off");

            if (MatchesKey(item, s.Protected))
                return FilterDecision.Make(FilterDecisionKind.ProtectedKeep, "user-protected");

            bool qualityOk = item.Quality >= s.MinQuality && item.Quality <= s.MaxQuality;
            string qReason = $"quality={item.Quality}";

            if (s.Mode == FishFilterMode.Whitelist)
            {
                bool listed = MatchesKey(item, s.Allowed);
                if (listed && qualityOk)
                    return FilterDecision.Make(FilterDecisionKind.Keep, "whitelisted");
                if (!listed)
                    return FilterDecision.Make(FilterDecisionKind.Trash, "not-in-whitelist");
                return FilterDecision.Make(FilterDecisionKind.Trash, qReason);
            }

            // Blacklist
            if (MatchesKey(item, s.Blocked))
                return FilterDecision.Make(FilterDecisionKind.Trash, "blacklisted");
            if (!qualityOk)
                return FilterDecision.Make(FilterDecisionKind.Trash, qReason);
            return FilterDecision.Make(FilterDecisionKind.Keep, "ok");
        }

        private static bool HasExplicitRule(CatchInfo item, FilterSettings s)
        {
            return MatchesKey(item, s.Allowed) || MatchesKey(item, s.Blocked) || MatchesKey(item, s.Protected);
        }

        /// <summary>Совпадение по id, квалифицированному id или имени.</summary>
        public static bool MatchesKey(CatchInfo item, HashSet<string> keys)
        {
            if (keys == null || keys.Count == 0) return false;
            return Contains(keys, item.ItemId)
                || Contains(keys, item.QualifiedItemId)
                || (item.DisplayName != null && keys.Contains(item.DisplayName));
        }

        private static bool Contains(HashSet<string> keys, string raw)
        {
            if (string.IsNullOrEmpty(raw)) return false;
            if (keys.Contains(raw)) return true;
            // допускаем запись без квалификатора "(O)"
            const string prefix = "(O)";
            if (raw.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) && keys.Contains(raw.Substring(prefix.Length)))
                return true;
            return false;
        }
    }
}
