using System;
using System.Collections.Generic;

namespace FishingAssistant.Pure
{
    /// <summary>Состояния конечного автомата авторыбалки.</summary>
    public enum FishingState
    {
        Idle,
        SelectingTarget,
        PreparingCast,
        Casting,
        WaitingForBite,
        Hooking,
        FishingMinigame,
        HandlingCatch,
        Cooldown,
        Paused,
        ErrorRecovery,
    }

    /// <summary>
    /// Таблица допустимых переходов автомата. Чистая логика, покрыта тестами:
    /// любые переходы вне таблицы запрещены и считаются ошибкой программирования.
    /// </summary>
    public static class FsmTransitions
    {
        private static readonly Dictionary<FishingState, HashSet<FishingState>> Allowed =
            new Dictionary<FishingState, HashSet<FishingState>>
            {
                [FishingState.Idle] = New(FishingState.SelectingTarget, FishingState.Paused),
                [FishingState.SelectingTarget] = New(
                    FishingState.PreparingCast, FishingState.Cooldown, FishingState.Paused, FishingState.Idle),
                [FishingState.PreparingCast] = New(
                    FishingState.Casting, FishingState.ErrorRecovery, FishingState.Paused),
                [FishingState.Casting] = New(
                    FishingState.WaitingForBite, FishingState.ErrorRecovery, FishingState.Paused),
                [FishingState.WaitingForBite] = New(
                    FishingState.Hooking, FishingState.Cooldown, FishingState.ErrorRecovery, FishingState.Paused),
                [FishingState.Hooking] = New(
                    FishingState.FishingMinigame, FishingState.WaitingForBite, FishingState.ErrorRecovery, FishingState.Paused),
                [FishingState.FishingMinigame] = New(
                    FishingState.HandlingCatch, FishingState.ErrorRecovery, FishingState.Paused),
                [FishingState.HandlingCatch] = New(
                    FishingState.Cooldown, FishingState.ErrorRecovery, FishingState.Paused),
                [FishingState.Cooldown] = New(
                    FishingState.SelectingTarget, FishingState.Idle, FishingState.Paused),
                [FishingState.Paused] = New(),   // выход задаётся динамически (ResumeTarget)
                [FishingState.ErrorRecovery] = New(
                    FishingState.Cooldown, FishingState.Idle, FishingState.Paused),
            };

        private static HashSet<FishingState> New(params FishingState[] states)
            => new HashSet<FishingState>(states);

        /// <summary>Разрешён ли переход.</summary>
        public static bool CanTransition(FishingState from, FishingState to)
        {
            return Allowed.TryGetValue(from, out var set) && set.Contains(to);
        }

        /// <summary>Все состояния, в которые можно перейти из указанного (без выхода из паузы).</summary>
        public static IReadOnlyCollection<FishingState> SuccessorsOf(FishingState from)
        {
            return Allowed.TryGetValue(from, out var set) ? (IReadOnlyCollection<FishingState>)set : Array.Empty<FishingState>();
        }
    }
}
