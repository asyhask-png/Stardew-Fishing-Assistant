﻿using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Tools;
using FishingAssistant.Core;
using FishingAssistant.Pure;

namespace FishingAssistant.Fishing
{
    /// <summary>
    /// Конечный автомат авторыбалки. Работает только через игровые апдейты (SMAPI UpdateTicked),
    /// без блокирующих задержек. Любое отключение мгновенно прекращает выдачу новых действий.
    /// </summary>
    public class AutoFishingDriver
    {
        private readonly Func<ModConfig> _config;
        private readonly CastPlanner _planner;
        private readonly MinigameController _minigame;

        private FishingState _state = FishingState.Idle;
        private readonly Stopwatch _stateTimer = new Stopwatch();
        private CastPlan _plan;
        private bool _releaseIssued;
        private string _pauseReason;
        private FishingState _resumeState = FishingState.Idle;
        private (int x, int y) _intendedLanding;
        private bool _calibrationPending;

        /// <summary>Текущее состояние (для диагностики и тестов).</summary>
        public FishingState State => _state;

        /// <summary>Причина текущей паузы или null.</summary>
        public string PauseReason => _state == FishingState.Paused ? _pauseReason : null;

        /// <summary>Создаёт автомат.</summary>
        public AutoFishingDriver(Func<ModConfig> config, CastPlanner planner, MinigameController minigame)
        {
            _config = config;
            _planner = planner;
            _minigame = minigame;
        }

        /// <summary>Полный сброс: остановка автоматизации, управление возвращается игроку.</summary>
        public void HardReset()
        {
            SetState(FishingState.Idle);
            _plan = null;
            _pauseReason = null;
            _resumeState = FishingState.Idle;
            _minigame.Reset();
            Log.Debug("autofish hard reset");
        }

        private void SetState(FishingState next)
        {
            if (_state == next)
                return;
            if (!FsmTransitions.CanTransition(_state, next))
            {
                // переход из Paused задаётся динамически
                if (!(_state == FishingState.Paused && next == _resumeState))
                {
                    Log.Warn($"FSM illegal transition {_state} → {next}, forcing reset");
                    _state = FishingState.Idle;
                }
            }
            Log.Debug($"FSM {_state} → {next}");
            _state = next;
            _stateTimer.Restart();
            _releaseIssued = false;
        }

        /// <summary>Один шаг автомата (каждый игровой тик).</summary>
        public void Tick()
        {
            var cfg = _config();

            if (!cfg.Enabled || !cfg.AutoFishingEnabled)
            {
                if (_state != FishingState.Idle)
                    HardReset();
                return;
            }
            if (!Context.IsWorldReady)
                return;

            // глобальные блокировки → пауза с сохранением точки возврата
            string block = GameHelper.BlockingReason();
            bool minigameRunning = GameHelper.ActiveBobberBar != null;

            if (block != null && !(block == "menu:BobberBar" && minigameRunning && _state == FishingState.FishingMinigame))
            {
                if (_state != FishingState.Paused)
                {
                    _resumeState = Resumable(_state) ? _state : FishingState.SelectingTarget;
                    _pauseReason = block;
                    SetState(FishingState.Paused);
                    if (block == "menu")
                        GameHelper.Notify("paused.menu");
                }
                return;
            }

            if (_state == FishingState.Paused)
            {
                _pauseReason = null;
                SetState(_resumeState);
                return;
            }

            switch (_state)
            {
                case FishingState.Idle:
                    if (GameHelper.IsPlayerFree())
                        SetState(FishingState.SelectingTarget);
                    break;

                case FishingState.SelectingTarget: TickSelectingTarget(cfg); break;
                case FishingState.PreparingCast: TickPreparingCast(cfg); break;
                case FishingState.Casting: TickCasting(cfg); break;
                case FishingState.WaitingForBite: TickWaitingForBite(cfg); break;
                case FishingState.Hooking: TickHooking(cfg); break;
                case FishingState.FishingMinigame: TickMinigame(cfg); break;
                case FishingState.HandlingCatch: TickHandlingCatch(cfg); break;
                case FishingState.Cooldown:
                    if (_stateTimer.ElapsedMilliseconds >= Math.Max(100, cfg.RecastDelayMs))
                        SetState(FishingState.SelectingTarget);
                    break;

                case FishingState.ErrorRecovery:
                    TryRecover();
                    SetState(FishingState.Cooldown);
                    break;
            }
        }

        private static bool Resumable(FishingState s)
            => s is FishingState.Casting or FishingState.WaitingForBite or FishingState.HandlingCatch or FishingState.Cooldown;

        private FishingRod Rod => GameHelper.EquippedRod;

        private void TickSelectingTarget(ModConfig cfg)
        {
            if (Rod == null)
            {
                // ждём удочку молча; подсказка раз в 15 секунд
                if (_stateTimer.ElapsedMilliseconds > 15000)
                {
                    GameHelper.Notify("rod.required");
                    _stateTimer.Restart();
                }
                return;
            }
            if (!GameHelper.HasRoomForCatch())
            {
                GameHelper.Notify("inventory.full");
                SetState(FishingState.Cooldown);
                return;
            }
            if (Rod.inUse())
                return; // игрок что-то делает сам

            var target = CurrentBubbleTarget?.Invoke();
            if (cfg.AutoCastWithoutBubbles == AutoCastWithoutBubbles.WaitBubbles && target == null)
                return; // ждём пузырьки молча (маршрут ведёт игрока, если он включён)

            _plan = _planner.Solve(Game1.currentLocation, target);
            if (_plan == null)
            {
                // нет воды в радиусе досягаемости — тихо ждём (маршрут ведёт игрока к берегу)
                if (_stateTimer.ElapsedMilliseconds > 3000)
                {
                    GameHelper.Notify("cast.stand.closer");
                    _stateTimer.Restart();
                }
                return;
            }

            _intendedLanding = _plan.Landing;
            _calibrationPending = true;
            SetState(FishingState.PreparingCast);
        }

        /// <summary>Внешний провайдер цели (пузырьки), устанавливается модом-энтри.</summary>
        public Func<Pure.BubbleTarget> CurrentBubbleTarget { get; set; }

        private void TickPreparingCast(ModConfig cfg)
        {
            var rod = Rod;
            if (rod == null || rod.inUse())
            {
                SetState(FishingState.ErrorRecovery);
                return;
            }
            if (Game1.player.Stamina <= 1f)
            {
                GameHelper.Notify("stamina.low");
                SetState(FishingState.Cooldown);
                return;
            }

            Game1.player.faceDirection(_plan.Facing);

            // короткая задержка на поворот, затем начало заброса
            if (_stateTimer.ElapsedMilliseconds >= 120)
            {
                try
                {
                    rod.beginUsing(Game1.currentLocation, Game1.player.TilePoint.X, Game1.player.TilePoint.Y, Game1.player);
                    SetState(FishingState.Casting);
                }
                catch (Exception ex)
                {
                    Log.Error("beginUsing failed", ex);
                    SetState(FishingState.ErrorRecovery);
                }
            }
        }

        private void TickCasting(ModConfig cfg)
        {
            var rod = Rod;
            if (rod == null)
            {
                SetState(FishingState.ErrorRecovery);
                return;
            }

            if (rod.isFishing)
            {
                // поплавок в воде
                if (_calibrationPending)
                {
                    CastPlanner.Calibrate(Game1.player, _intendedLanding, new Vector2(rod.bobber.X, rod.bobber.Y));
                    _calibrationPending = false;
                }
                SetState(FishingState.WaitingForBite);
                return;
            }

            if (rod.isTimingCast && !_releaseIssued)
            {
                float power = rod.castingPower;
                bool rising = rod.castingTimerSpeed >= 0;
                if ((rising && power >= _plan.Power) || power >= 1f)
                {
                    // имитация отпускания кнопки в нужный момент
                    rod.isTimingCast = false;
                    rod.isCasting = true;
                    rod.castingChosenCountdown = Math.Max(1, (int)(_plan.Power * 1000f));
                    rod.castingPower = _plan.Power;
                    _releaseIssued = true;
                    Log.Debug($"cast released at power={_plan.Power:0.00}");
                }
                return;
            }

            // фаза полёта/отсчёта — просто ждём
            if (_stateTimer.ElapsedMilliseconds > 8000)
                SetState(FishingState.ErrorRecovery);
        }

        private void TickWaitingForBite(ModConfig cfg)
        {
            var rod = Rod;
            if (rod == null)
            {
                SetState(FishingState.ErrorRecovery);
                return;
            }
            if (!rod.isFishing)
            {
                // поплавок вытащен игроком или игра сбросила заброс
                SetState(FishingState.Cooldown);
                return;
            }
            if (cfg.BiteTimeoutMs > 0 && _stateTimer.ElapsedMilliseconds > cfg.BiteTimeoutMs + 20000)
            {
                SetState(FishingState.ErrorRecovery);
                return;
            }

            // поклёвка: окно подсечки
            if (rod.isNibbling && !rod.hit && !rod.showingTreasure)
                SetState(FishingState.Hooking);
        }

        private void TickHooking(ModConfig cfg)
        {
            var rod = Rod;
            if (rod == null)
            {
                SetState(FishingState.ErrorRecovery);
                return;
            }
            if (rod.hit || GameHelper.ActiveBobberBar != null)
            {
                SetState(FishingState.FishingMinigame);
                return;
            }
            if (!rod.isNibbling)
            {
                SetState(FishingState.WaitingForBite); // промахнулись по окну, ждём следующую поклёвку
                return;
            }

            // однократная подсечка обычным вызовом DoFunction — как нажатие кнопки игроком
            if (!_releaseIssued)
            {
                _releaseIssued = true;
                try
                {
                    rod.DoFunction(Game1.currentLocation, Game1.player.TilePoint.X, Game1.player.TilePoint.Y, 0, Game1.player);
                    Log.Debug("hooked!");
                }
                catch (Exception ex)
                {
                    Log.Error("hook DoFunction failed", ex);
                    SetState(FishingState.ErrorRecovery);
                }
            }
        }

        private void TickMinigame(ModConfig cfg)
        {
            if (GameHelper.ActiveBobberBar == null)
            {
                SetState(FishingState.HandlingCatch);
                return;
            }
            _minigame.Tick(); // управление внутри; при отключённой функции планку ведёт игрок

            if (_stateTimer.ElapsedMilliseconds > 180000)
                SetState(FishingState.ErrorRecovery); // что-то пошло не так: 3 минуты на рыбу
        }

        private void TickHandlingCatch(ModConfig cfg)
        {
            var rod = Rod;
            if (rod == null || !rod.inUse())
            {
                SetState(FishingState.Cooldown);
                return;
            }
            if (_stateTimer.ElapsedMilliseconds > 12000)
                SetState(FishingState.ErrorRecovery);
        }

        private void TryRecover()
        {
            try
            {
                var rod = Rod;
                if (rod != null && rod.inUse() && !rod.isNibbling && !rod.hit && GameHelper.ActiveBobberBar == null)
                {
                    rod.doneFishing(Game1.player, consumeBaitAndTackle: false);
                    Log.Debug("recovery: doneFishing called");
                }
            }
            catch (Exception ex)
            {
                Log.Debug("recovery fail: " + ex.Message);
            }
        }

        /// <summary>Игрок сменил локацию — цикл прерывается безопасно.</summary>
        public void OnLocationChanged()
        {
            if (_state is FishingState.PreparingCast or FishingState.Casting or FishingState.WaitingForBite
                or FishingState.Hooking or FishingState.FishingMinigame or FishingState.HandlingCatch)
            {
                TryRecoverSilently();
                SetState(FishingState.SelectingTarget);
            }
        }

        private void TryRecoverSilently()
        {
            try
            {
                var rod = Rod;
                if (rod != null && rod.inUse() && GameHelper.ActiveBobberBar == null && !rod.isNibbling)
                    rod.doneFishing(Game1.player, consumeBaitAndTackle: false);
            }
            catch { }
            _minigame.Reset();
        }
    }
}

