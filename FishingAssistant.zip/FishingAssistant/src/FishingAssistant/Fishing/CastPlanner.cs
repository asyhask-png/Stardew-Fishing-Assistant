﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using StardewValley;
using FishingAssistant.Core;
using FishingAssistant.Routing;
using FishingAssistant.Pure;

namespace FishingAssistant.Fishing
{
    /// <summary>Результат решения задачи заброса.</summary>
    public class CastPlan
    {
        /// <summary>Направление взгляда: 0 вверх, 1 вправо, 2 вниз, 3 влево.</summary>
        public int Facing;

        /// <summary>Сила заброса 0..1.</summary>
        public float Power;

        /// <summary>Клетка воды, куда должен упасть поплавок.</summary>
        public (int x, int y) Landing;

        /// <summary>Точное попадание в пузырьки.</summary>
        public bool ExactHit;
    }

    /// <summary>
    /// Выбирает точку заброса: клетку воды, направление и силу.
    /// Работает только с текущей позицией игрока — не телепортирует и не двигает его.
    /// </summary>
    public class CastPlanner
    {
        private readonly Func<ModConfig> _config;

        /// <summary>Адаптивная калибровка силы по паре (уровень удочки, уровень рыбалки).</summary>
        private static readonly Dictionary<int, float> PowerCorrection = new Dictionary<int, float>();

        /// <summary>Создаёт планировщик.</summary>
        public CastPlanner(Func<ModConfig> config) => _config = config;

        /// <summary>
        /// Строит план заброса из текущей клетки игрока.
        /// Если target задан в текущей локации — старается попасть прямо в пузырьки.
        /// </summary>
        public CastPlan Solve(GameLocation loc, Pure.BubbleTarget target)
        {
            if (loc == null || Game1.player == null || Game1.player.CurrentTool == null)
                return null;

            var stand = (x: Game1.player.TilePoint.X, y: Game1.player.TilePoint.Y);
            Passability.MakeGrid(loc, out var inB, out var walk);
            if (!inB(stand.x, stand.y))
                return null;
            if (Passability.IsFishableWater(loc, stand.x, stand.y))
                return null; // стоим в воде

            int maxTiles = CastScoring.MaxCastTiles(Game1.player.fishingLevel.Value);
            bool hasTarget = target != null && target.LocationName.Equals(loc.Name, StringComparison.OrdinalIgnoreCase);

            var candidates = new List<CastCandidate>();
            foreach (int facing in new[] { 0, 1, 2, 3 })
            {
                var (dx, dy) = FacingDelta(facing);

                for (int dist = 2; dist <= maxTiles; dist++)
                {
                    var land = (x: stand.x + dx * dist, y: stand.y + dy * dist);
                    if (!inB(land.x, land.y))
                        break; // за краем карты дальше лететь некуда
                    if (!Passability.IsFishableWater(loc, land.x, land.y))
                        continue;
                    if (!AxisLineClear(loc, inB, walk, stand, land))
                        continue;

                    candidates.Add(new CastCandidate
                    {
                        StandX = stand.x,
                        StandY = stand.y,
                        LandingX = land.x,
                        LandingY = land.y,
                        Facing = facing,
                        Power = PowerFor(stand, land, maxTiles),
                        ExactHit = hasTarget && land.x == target.X && land.y == target.Y,
                        DistTiles = dist,
                        MissTiles = hasTarget ? Math.Abs(target.X - land.x) + Math.Abs(target.Y - land.y) : 0f,
                    });
                }
            }

            var best = CastScoring.Best(candidates, hasTarget);
            if (best == null)
                return null;

            var c = best.Value;
            if (hasTarget && c.MissTiles > 0)
                GameHelper.Notify("cast.adjusted", new { tiles = (int)Math.Min(c.MissTiles, 99) });

            return new CastPlan
            {
                Facing = c.Facing,
                Power = c.Power,
                Landing = (c.LandingX, c.LandingY),
                ExactHit = !hasTarget || c.ExactHit,
            };
        }

        private static (int dx, int dy) FacingDelta(int facing) => facing switch
        {
            0 => (0, -1),
            1 => (1, 0),
            2 => (0, 1),
            3 => (-1, 0),
            _ => (0, -1),
        };

        /// <summary>Линия полёта вдоль одного направления: клетки должны быть водой или свободной землёй.</summary>
        private static bool AxisLineClear(
            GameLocation loc,
            PassabilityPredicate inB,
            PassabilityPredicate walk,
            (int x, int y) from,
            (int x, int y) to)
        {
            int dx = Math.Sign(to.x - from.x), dy = Math.Sign(to.y - from.y);
            int x = from.x + dx, y = from.y + dy;
            while (x != to.x || y != to.y)
            {
                if (!CellOk(loc, inB, walk, x, y)) return false;
                x += dx; y += dy;
            }
            return CellOk(loc, inB, walk, to.x, to.y);
        }

        private static bool CellOk(GameLocation loc, PassabilityPredicate inB, PassabilityPredicate walk, int x, int y)
        {
            if (!inB(x, y)) return false;
            return Passability.IsFishableWater(loc, x, y) || walk(x, y);
        }

        private float PowerFor((int x, int y) stand, (int x, int y) land, int maxTiles)
        {
            float distTiles = Vector2.Distance(new Vector2(stand.x, stand.y), new Vector2(land.x, land.y));
            float basePower = CastScoring.PowerForDistance(distTiles + 8f / 64f, maxTiles);

            int key = CalibrationKey(Game1.player);
            PowerCorrection.TryGetValue(key, out float corr);
            if (corr == 0f) corr = 1f;
            return Math.Clamp(basePower * corr, 0.08f, 1f);
        }

        private static int CalibrationKey(Farmer who)
            => ((who.CurrentTool?.UpgradeLevel ?? 0) * 100) + who.fishingLevel.Value;

        /// <summary>Учитывает фактическую дальность заброса для уточнения силы (адаптивная калибровка).</summary>
        public static void Calibrate(Farmer who, (int x, int y) intended, Vector2 bobberPx)
        {
            try
            {
                if (who?.CurrentTool == null)
                    return;
                var actual = (x: (int)(bobberPx.X / 64f), y: (int)(bobberPx.Y / 64f));
                var stand = new Vector2(who.TilePoint.X, who.TilePoint.Y);

                float intendedDist = Vector2.Distance(stand, new Vector2(intended.x, intended.y));
                float actualDist = Vector2.Distance(stand, new Vector2(actual.x, actual.y));
                if (actualDist < 0.5f || intendedDist < 0.5f || Math.Abs(actualDist - intendedDist) < 0.4f)
                    return;

                float ratio = Math.Clamp(intendedDist / actualDist, 0.7f, 1.4f);
                int key = CalibrationKey(who);
                PowerCorrection.TryGetValue(key, out float old);
                if (old == 0f) old = 1f;
                PowerCorrection[key] = Math.Clamp(old * 0.7f + ratio * 0.3f, 0.7f, 1.4f);
                Log.Debug($"cast calibration: ratio={ratio:0.00} corr={PowerCorrection[key]:0.00}");
            }
            catch { }
        }
    }
}

