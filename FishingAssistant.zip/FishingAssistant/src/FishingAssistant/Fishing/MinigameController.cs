﻿using System;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Menus;
using FishingAssistant.Core;
using FishingAssistant.Pure;

namespace FishingAssistant.Fishing
{
    /// <summary>
    /// Автоматическое прохождение мини-игры рыбалки и сбор сокровищ.
    /// Управление выполняется инжекцией ускорения планки (эквивалент удержания кнопки):
    /// поле <c>BobberBar.buttonPressed</c> игра перезаписывает из сырого ввода каждый кадр,
    /// поэтому прямое «виртуальное нажатие» невозможно — подтверждено дизассемблированием 1.6.15.
    /// Прогресс и результат напрямую не изменяются: мини-игра проходится обычной физикой игры.
    /// </summary>
    public class MinigameController
    {
        private readonly Func<ModConfig> _config;

        private BobberBar _bar;
        private bool _chasingTreasure;
        private bool _disabledByIncompatibility;

        /// <summary>Создаёт контроллер мини-игры.</summary>
        public MinigameController(Func<ModConfig> config) => _config = config;

        /// <summary>Модуль аварийно отключён из-за несовместимости.</summary>
        public bool DisabledByIncompatibility => _disabledByIncompatibility;

        /// <summary>ID рыбы активной мини-игры (для фильтра), null если мини-игры нет.</summary>
        public string ActiveFishId => _bar?.whichFish;

        /// <summary>Была ли поймана рыба в последней мини-игре (не мусор).</summary>
        public bool LastWasBossFish { get; private set; }

        /// <summary>Полностью сбрасывает состояние между сессиями.</summary>
        public void Reset()
        {
            _bar = null;
            _chasingTreasure = false;
            LastWasBossFish = false;
        }

        /// <summary>Вызывается каждый игровой тик. Возвращает true, пока идёт управление.</summary>
        public bool Tick()
        {
            var cfg = _config();
            if (!cfg.Enabled || !cfg.PerfectFishingEnabled || !Context.IsWorldReady)
                return ReleaseControl();

            try
            {
                var bar = GameHelper.ActiveBobberBar;
                if (bar == null)
                {
                    _bar = null;
                    return false;
                }
                if (_bar != bar)
                {
                    _bar = bar;
                    _chasingTreasure = false;
                    LastWasBossFish = bar.bossFish;
                    Log.Debug($"minigame started: fish={bar.whichFish} diff={bar.difficulty:0.##}");
                }

                if (_disabledByIncompatibility)
                    return false;

                var snap = ReadSnapshot(bar);
                if (!snap.HasValue)
                {
                    OnIncompatible(cfg);
                    return false;
                }
                var s = snap.Value;

                // выбор цели «рыба / сундук»
                switch (TreasureRiskModel.Decide(s, cfg.TreasureMode, _chasingTreasure))
                {
                    case MinigameGoal.ChaseTreasure:
                        _chasingTreasure = true;
                        break;
                    case MinigameGoal.HoldFish:
                        if (_chasingTreasure && TreasureRiskModel.ShouldAbortChase(s, cfg.TreasureMode))
                            _chasingTreasure = false;
                        else if (!_chasingTreasure)
                            _chasingTreasure = false;
                        break;
                }
                if (_chasingTreasure && TreasureRiskModel.ShouldAbortChase(s, cfg.TreasureMode))
                    _chasingTreasure = false;

                float target = _chasingTreasure ? s.TreasurePos : s.FishPos;

                // регулятор планки
                float accel = BarController.ComputeAcceleration(
                    s.BarCenter, s.BarSpeed, target,
                    Math.Max(2f, cfg.MinigameTolerancePx),
                    cfg.MinigameStrength,
                    cfg.MinigameAnticipate);

                if (accel != 0f && !bar.fadeIn && !bar.fadeOut && !bar.handledFishResult)
                {
                    // инжекция ускорения после игрового апдейта — эквивалент нажатой/отпущенной кнопки на следующем тике
                    bar.bobberBarSpeed += accel;
                    Log.Debug($"bar: err={s.BarCenter - target:0.0} v={s.BarSpeed:0.00} a={accel:0.00} chase={_chasingTreasure}");
                }

                if (bar.handledFishResult || bar.fadeOut)
                {
                    Log.Debug($"minigame ending: progress={bar.distanceFromCatching:0.00} perfect={bar.perfect} treasure={bar.treasureCaught}");
                    _bar = null;
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                Log.Error("MinigameController tick failed", ex);
                OnIncompatible(cfg);
                return false;
            }
        }

        private MinigameSnapshot? ReadSnapshot(BobberBar bar)
        {
            try
            {
                int h = bar.bobberBarHeight;
                // центр окна планки в системе координат шкалы (смещение -32 подтверждено IL)
                float barCenter = bar.bobberBarPos + h / 2f - 32f;
                return new MinigameSnapshot
                {
                    FishPos = bar.bobberPosition,
                    BarCenter = barCenter,
                    BarHalf = h / 2f,
                    BarSpeed = bar.bobberBarSpeed,
                    Progress = bar.distanceFromCatching,
                    TreasurePresent = bar.treasure,
                    TreasurePos = bar.treasurePosition,
                    TreasureCaught = bar.treasureCaught,
                    TreasureProgress = bar.treasureCatchLevel,
                    FishInBar = bar.bobberInBar,
                };
            }
            catch (Exception ex)
            {
                Log.Debug("snapshot fail: " + ex.Message);
                return null;
            }
        }

        private void OnIncompatible(ModConfig cfg)
        {
            if (!cfg.MinigameSafeMode)
                return;
            if (_disabledByIncompatibility)
                return;
            _disabledByIncompatibility = true;
            GameHelper.Notify("module.minigame.incompatible");
            Log.Warn("Perfect fishing disabled: minigame structure differs from supported SDV 1.6 layout.");
        }

        private bool ReleaseControl()
        {
            _bar = null;
            _chasingTreasure = false;
            return false;
        }
    }
}

