using System;
using System.Collections.Generic;
using System.Linq;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Menus;
using FishingAssistant.Core;

namespace FishingAssistant
{
    /// <summary>
    /// Совместимость: интеграция с Generic Mod Config Menu (необязательная),
    /// обнаружение конфликтующих рыболовных модов и проверка структуры мини-игры.
    /// </summary>
    public class CompatibilityManager
    {
        /// <summary>Известные признаки других модов автоматизации рыбалки.</summary>
        private static readonly string[] KnownConflicts =
        {
            "autofish", "easyfishing", "skipfishingminigame", "instantfishing",
            "fishingautomation", "betterfishing",
        };

        private readonly IModHelper _helper;
        private readonly IManifest _manifest;

        private IGenericModConfigMenuApi _gmcm;

        /// <summary>Создаёт менеджер совместимости.</summary>
        public CompatibilityManager(IModHelper helper, IManifest manifest)
        {
            _helper = helper;
            _manifest = manifest;
        }

        /// <summary>Проверяет структуру BobberBar; false — идеальная рыбалка недоступна.</summary>
        public bool ProbeMinigameSupport()
        {
            try
            {
                var t = typeof(BobberBar);
                string[] required =
                {
                    nameof(BobberBar.bobberPosition), nameof(BobberBar.bobberBarPos),
                    nameof(BobberBar.bobberBarSpeed), nameof(BobberBar.bobberBarHeight),
                    nameof(BobberBar.distanceFromCatching), nameof(BobberBar.treasure),
                    nameof(BobberBar.treasurePosition), nameof(BobberBar.perfect),
                };
                foreach (var name in required)
                    if (t.GetField(name) == null)
                    {
                        Log.Warn($"BobberBar.{name} not found — minigame module unavailable.");
                        return false;
                    }
                return true;
            }
            catch (Exception ex)
            {
                Log.Error("minigame probe failed", ex);
                return false;
            }
        }

        /// <summary>Ищет потенциальные конфликты. Возвращает список имён (пусто — конфликтов нет).</summary>
        public string[] DetectConflicts(ModConfig cfg)
        {
            if (!cfg.RespectConflictingMods)
                return Array.Empty<string>();

            var hits = _helper.ModRegistry.GetAll()
                .Where(m => !string.Equals(m.Manifest.UniqueID, _manifest.UniqueID, StringComparison.OrdinalIgnoreCase))
                .Where(m =>
                {
                    string hay = ((m.Manifest.UniqueID ?? "") + " " + (m.Manifest.Name ?? "")).ToLowerInvariant();
                    return KnownConflicts.Any(hay.Contains);
                })
                .Select(m => $"{m.Manifest.Name} ({m.Manifest.UniqueID})")
                .ToArray();

            if (hits.Length > 0)
                GameHelper.Notify("conflict.detected", new { mods = string.Join(", ", hits) });
            return hits;
        }

        /// <summary>Регистрирует настройки в GMCM, если он установлен.</summary>
        public void TryRegisterGmcm(ModConfig config, Action saveAndApply)
        {
            try
            {
                if (!_helper.ModRegistry.IsLoaded("spacechase0.GenericModConfigMenu"))
                    return;
                _gmcm = _helper.ModRegistry.GetApi<IGenericModConfigMenuApi>("spacechase0.GenericModConfigMenu");
                if (_gmcm == null)
                    return;

                _gmcm.Register(_manifest, ResetDefaults, saveAndApply);

                _gmcm.AddSectionTitle(_manifest, () => T("gmcm.section.modules"));
                Bool(nameof(config.Enabled), () => config.Enabled, v => config.Enabled = v);
                Bool(nameof(config.BubbleDetectionEnabled), () => config.BubbleDetectionEnabled, v => config.BubbleDetectionEnabled = v);
                Bool(nameof(config.BubbleNotificationsEnabled), () => config.BubbleNotificationsEnabled, v => config.BubbleNotificationsEnabled = v);
                Bool(nameof(config.RouteEnabled), () => config.RouteEnabled, v => config.RouteEnabled = v);
                Bool(nameof(config.AutoFishingEnabled), () => config.AutoFishingEnabled, v => config.AutoFishingEnabled = v);
                Bool(nameof(config.PerfectFishingEnabled), () => config.PerfectFishingEnabled, v => config.PerfectFishingEnabled = v);

                EnumOption<TreasureMode>(nameof(config.TreasureMode), () => config.TreasureMode, v => config.TreasureMode = v);
                EnumOption<FishFilterMode>(nameof(config.FishFilterMode), () => config.FishFilterMode, v => config.FishFilterMode = v);
                EnumOption<TargetSelectionMode>(nameof(config.TargetSelection), () => config.TargetSelection, v => config.TargetSelection = v);

                _gmcm.AddSectionTitle(_manifest, () => T("gmcm.section.minigame"));
                Num(nameof(config.MinigameTolerancePx), 2f, 60f, 1f, () => config.MinigameTolerancePx, v => config.MinigameTolerancePx = v);
                Num(nameof(config.MinigameStrength), 0.2f, 2f, 0.05f, () => config.MinigameStrength, v => config.MinigameStrength = v);

                _gmcm.AddSectionTitle(_manifest, () => T("gmcm.section.keys"));
                Key(nameof(config.MasterToggleKey), () => config.MasterToggleKey, v => config.MasterToggleKey = v);
                Key(nameof(config.RouteToggleKey), () => config.RouteToggleKey, v => config.RouteToggleKey = v);
                Key(nameof(config.AutoFishingToggleKey), () => config.AutoFishingToggleKey, v => config.AutoFishingToggleKey = v);
                Key(nameof(config.PerfectFishingToggleKey), () => config.PerfectFishingToggleKey, v => config.PerfectFishingToggleKey = v);
                Key(nameof(config.TreasureToggleKey), () => config.TreasureToggleKey, v => config.TreasureToggleKey = v);
                Key(nameof(config.NextTargetKey), () => config.NextTargetKey, v => config.NextTargetKey = v);

                Log.Info("GMCM integration registered.");
            }
            catch (Exception ex)
            {
                Log.Debug("GMCM registration skipped: " + ex.Message);
            }
        }

        private void Bool(string key, Func<bool> get, Action<bool> set) =>
            _gmcm.AddBoolOption(_manifest, get, set, () => T("config." + key));

        private void Num(string key, float min, float max, float step, Func<float> get, Action<float> set) =>
            _gmcm.AddNumberOption(_manifest, get, set, () => T("config." + key), min: min, max: max, interval: step);

        private void Key(string key, Func<SButton> get, Action<SButton> set) =>
            _gmcm.AddKeybind(_manifest, get, set, () => T("config." + key));

        private void EnumOption<TEnum>(string key, Func<TEnum> get, Action<TEnum> set)
            where TEnum : struct, Enum
        {
            string[] values = Enum.GetNames(typeof(TEnum));
            _gmcm.AddTextOption(
                _manifest,
                () => Enum.GetName(typeof(TEnum), get()),
                v => { if (Enum.TryParse(v, out TEnum parsed)) set(parsed); },
                () => T("config." + key),
                allowedValues: values);
        }

        private void ResetDefaults()
        {
            var fresh = new ModConfig();
            var current = _helper.ReadConfig<ModConfig>();
            foreach (var prop in typeof(ModConfig).GetProperties())
                if (prop.CanWrite)
                    prop.SetValue(current, prop.GetValue(fresh));
            _helper.WriteConfig(current);
        }

        private string T(string key) => GameHelper.T(key);
    }
}
