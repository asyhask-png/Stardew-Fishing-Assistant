using System;
using System.Linq;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Menus;
using FishingAssistant.Bubbles;
using FishingAssistant.Core;
using FishingAssistant.Filtering;
using FishingAssistant.Fishing;
using FishingAssistant.Input;
using FishingAssistant.Pure;
using FishingAssistant.Rendering;
using FishingAssistant.Routing;

namespace FishingAssistant
{
    /// <summary>Точка входа мода Fishing Assistant.</summary>
    public class ModEntry : Mod
    {
        private ModConfig _config;
        private BubbleTracker _bubbles;
        private RouteManager _routes;
        private CastPlanner _planner;
        private MinigameController _minigame;
        private AutoFishingDriver _driver;
        private CatchFilter _filter;
        private RouteRenderer _renderer;
        private CompatibilityManager _compat;
        private bool _barWasPresent;
        private string[] _conflictingMods = Array.Empty<string>();

        /// <inheritdoc/>
        public override void Entry(IModHelper helper)
        {
            _config = helper.ReadConfig<ModConfig>();
            Log.Init(Monitor);
            GameHelper.Helper = helper;

            _bubbles = new BubbleTracker(() => _config);
            _routes = new RouteManager(() => _config);
            _routes.AttachBubbles(_bubbles);
            _planner = new CastPlanner(() => _config);
            _minigame = new MinigameController(() => _config);
            _filter = new CatchFilter(() => _config);
            _driver = new AutoFishingDriver(() => _config, _planner, _minigame)
            {
                CurrentBubbleTarget = ResolveCurrentBubbleTarget,
            };
            _renderer = new RouteRenderer(() => _config, () => _routes.GetRoute());
            _compat = new CompatibilityManager(helper, ModManifest);

            ApplyConfigFlags();

            var input = new InputManager(
                () => _config,
                ToggleMaster,
                ToggleRoute,
                ToggleAutoFishing,
                TogglePerfect,
                CycleTreasureMode,
                NextTarget);

            // --- события игры ---
            helper.Events.GameLoop.GameLaunched += OnGameLaunched;
            helper.Events.GameLoop.SaveLoaded += OnSaveLoaded;
            helper.Events.GameLoop.DayStarted += OnDayStarted;
            helper.Events.GameLoop.OneSecondUpdateTicked += OnOneSecondTicked;
            helper.Events.GameLoop.UpdateTicked += OnUpdateTicked;
            helper.Events.Display.RenderedWorld += (_, e) => Safe(() => _renderer.Draw(this, e), "render");
            helper.Events.Player.InventoryChanged += OnInventoryChanged;
            helper.Events.Player.Warped += OnWarped;
            helper.Events.World.LocationListChanged += OnLocationListChanged;
            input.Attach(helper.Events);

            RegisterConsoleCommands(helper);
            Log.Info($"{ModManifest.Name} {ModManifest.Version} loaded (SDV 1.6, SMAPI 4+). Press F6 to toggle.");
        }

        // ------------------------------------------------------------------ события

        private void OnGameLaunched(object sender, GameLaunchedEventArgs e)
        {
            _compat.TryRegisterGmcm(_config, SaveConfig);
            _conflictingMods = _compat.DetectConflicts(_config);
            if (_conflictingMods.Length > 0 && !_compat.ProbeMinigameSupport())
                Log.Warn("Conflicts detected AND minigame probe failed — perfect fishing will stay off.");
        }

        private void OnSaveLoaded(object sender, SaveLoadedEventArgs e)
        {
            ResetSessionCaches();
        }

        private void OnDayStarted(object sender, DayStartedEventArgs e)
        {
            ResetSessionCaches();
        }

        private void ResetSessionCaches()
        {
            _bubbles.Reset();
            _routes.RebuildGraph();   // граф локаций кешируется на день
            _filter.Reset();
            _minigame.Reset();
            _driver.HardReset();
            Log.Debug("session caches cleared");
        }

        private void OnOneSecondTicked(object sender, OneSecondUpdateTickedEventArgs e)
        {
            Safe(() => _bubbles.Scan(), "bubble-scan");
        }

        private void OnUpdateTicked(object sender, UpdateTickedEventArgs e)
        {
            Safe(() =>
            {
                // отслеживание появления/исчезновения сундука для фильтра
                var bar = GameHelper.ActiveBobberBar;
                bool present = bar != null;
                if (present && !_barWasPresent && bar.treasure)
                    _filter.MarkTreasurePending();
                if (_barWasPresent && !present && _config.Enabled)
                    _filter.OnCatchLanded();
                _barWasPresent = present;

                _driver.Tick();
            }, "update");
        }

        private void OnInventoryChanged(object sender, InventoryChangedEventArgs e)
        {
            Safe(() => _filter.OnInventoryChanged(sender, e), "inventory");
        }

        private void OnWarped(object sender, WarpedEventArgs e)
        {
            if (!e.IsLocalPlayer)
                return;
            _routes.Invalidate();     // маршрут пересчитается от новой позиции
            _driver.OnLocationChanged();
        }

        private void OnLocationListChanged(object sender, LocationListChangedEventArgs e)
        {
            // модовые карты могли догрузиться — обновим граф при следующем построении маршрута
            Safe(() => _routes.Graph.Rebuild(), "graph-rebuild");
        }

        // ------------------------------------------------------------------ горячие клавиши

        private BubbleTarget ResolveCurrentBubbleTarget()
        {
            var target = _routes.SelectTarget();
            if (target == null || !Context.IsWorldReady)
                return null;
            return target.LocationName.Equals(Game1.currentLocation?.Name, StringComparison.OrdinalIgnoreCase)
                ? target
                : null; // заброс возможен только в текущей локации; до другой ведёт маршрут
        }

        private void ToggleMaster()
        {
            _config.Enabled = !_config.Enabled;
            ApplyConfigFlags();
            if (!_config.Enabled)
            {
                _driver.HardReset();      // мгновенно освобождаем управление
                _bubbles.Reset();
            }
            GameHelper.Notify(_config.Enabled ? "master.enabled" : "master.disabled");
            SaveConfig();
        }

        private void ToggleRoute()
        {
            if (!_config.Enabled) return;
            _config.RouteEnabled = !_config.RouteEnabled;
            _routes.Invalidate();
            GameHelper.Notify(_config.RouteEnabled ? "route.enabled" : "route.disabled");
            SaveConfig();
        }

        private void ToggleAutoFishing()
        {
            if (!_config.Enabled) return;
            _config.AutoFishingEnabled = !_config.AutoFishingEnabled;
            if (!_config.AutoFishingEnabled)
                _driver.HardReset();
            GameHelper.Notify(_config.AutoFishingEnabled ? "autofish.enabled" : "autofish.disabled");
            SaveConfig();
        }

        private void TogglePerfect()
        {
            if (!_config.Enabled) return;
            _config.PerfectFishingEnabled = !_config.PerfectFishingEnabled;
            GameHelper.Notify(_config.PerfectFishingEnabled ? "perfect.enabled" : "perfect.disabled");
            SaveConfig();
        }

        private void CycleTreasureMode()
        {
            if (!_config.Enabled) return;
            _config.TreasureMode = _config.TreasureMode switch
            {
                TreasureMode.Off => TreasureMode.SafeOnly,
                TreasureMode.SafeOnly => TreasureMode.AlwaysTry,
                _ => TreasureMode.Off,
            };
            GameHelper.Notify("treasure.state", new { mode = _config.TreasureMode });
            SaveConfig();
        }

        private void NextTarget()
        {
            if (!_config.Enabled) return;
            _routes.CycleManualTarget();
            _routes.Invalidate();
            SaveConfig();
        }

        private void ApplyConfigFlags()
        {
            Log.DebugEnabled = _config.DebugLogging;
        }

        private void SaveConfig() => Helper.WriteConfig(_config);

        // ------------------------------------------------------------------ консоль

        private void RegisterConsoleCommands(IModHelper helper)
        {
            helper.ConsoleCommands.Add("fa_status", "Fishing Assistant: show module status.", (_, __) =>
            {
                var rod = GameHelper.EquippedRod;
                Monitor.Log($@"
Fishing Assistant status
  enabled          : {_config.Enabled}
  bubbles tracked  : {_bubbles.Active.Count}
    {string.Join("\n    ", _bubbles.Active.Select(t => t.ToString()).DefaultIfEmpty("-"))}
  auto fishing     : {_config.AutoFishingEnabled} (state: {_driver.State}, pause: {_driver.PauseReason ?? "-"})
  perfect fishing  : {_config.PerfectFishingEnabled} (incompatible: {_minigame.DisabledByIncompatibility})
  treasure mode    : {_config.TreasureMode}
  route            : {_config.RouteEnabled}
  rod              : {(rod == null ? "none" : $"{rod.Name} lvl{rod.UpgradeLevel}")}
  conflicts        : {(_conflictingMods.Length == 0 ? "none" : string.Join(", ", _conflictingMods))}
  graph locations  : {_routes.Graph.KnownLocations.Count}".TrimStart());
            });

            helper.ConsoleCommands.Add("fa_toggle", "Fishing Assistant: toggle module (autofish|perfect|route|enabled).", (_, args) =>
            {
                switch (args.FirstOrDefault()?.ToLowerInvariant())
                {
                    case "autofish": ToggleAutoFishing(); break;
                    case "perfect": TogglePerfect(); break;
                    case "route": ToggleRoute(); break;
                    case "enabled": ToggleMaster(); break;
                    default: Monitor.Log("Usage: fa_toggle <autofish|perfect|route|enabled>"); break;
                }
                Monitor.Log($"auto={_config.AutoFishingEnabled} perfect={_config.PerfectFishingEnabled} route={_config.RouteEnabled} enabled={_config.Enabled}");
            });

            helper.ConsoleCommands.Add("fa_log", "Fishing Assistant: show catch-filter journal.", (_, __) =>
            {
                var entries = Log.SessionJournal;
                Monitor.Log(entries.Count == 0 ? "(journal empty)" : string.Join("\n", entries));
            });

            helper.ConsoleCommands.Add("fa_scan", "Fishing Assistant: rescan bubbles now.", (_, __) =>
            {
                _bubbles.Reset();
                _bubbles.Scan();
                foreach (var t in _bubbles.Active)
                    Monitor.Log("bubble: " + t);
            });
        }

        private void Safe(Action action, string tag)
        {
            try
            {
                action();
            }
            catch (Exception ex)
            {
                Log.Error($"tick '{tag}' failed", ex);
            }
        }
    }
}
