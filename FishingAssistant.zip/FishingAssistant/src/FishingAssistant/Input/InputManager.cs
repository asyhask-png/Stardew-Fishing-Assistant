using System;
using System.Linq;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using FishingAssistant.Core;

namespace FishingAssistant.Input
{
    /// <summary>
    /// Горячие клавиши. Каждая работает независимо; главная клавиша мгновенно
    /// останавливает автоматизацию и возвращает управление игроку.
    /// </summary>
    public class InputManager
    {
        private readonly Func<ModConfig> _config;
        private readonly Action _toggleMaster;
        private readonly Action _toggleRoute;
        private readonly Action _toggleAutoFishing;
        private readonly Action _togglePerfect;
        private readonly Action _cycleTreasure;
        private readonly Action _nextTarget;

        /// <summary>Создаёт обработчик клавиш.</summary>
        public InputManager(
            Func<ModConfig> config,
            Action toggleMaster,
            Action toggleRoute,
            Action toggleAutoFishing,
            Action togglePerfect,
            Action cycleTreasure,
            Action nextTarget)
        {
            _config = config;
            _toggleMaster = toggleMaster;
            _toggleRoute = toggleRoute;
            _toggleAutoFishing = toggleAutoFishing;
            _togglePerfect = togglePerfect;
            _cycleTreasure = cycleTreasure;
            _nextTarget = nextTarget;
        }

        /// <summary>Подписка на ButtonsChanged.</summary>
        public void Attach(IModEvents events)
        {
            events.Input.ButtonsChanged += OnButtonsChanged;
        }

        private void OnButtonsChanged(object sender, ButtonsChangedEventArgs e)
        {
            var cfg = _config();

            // главная клавиша работает всегда — это аварийный выключатель
            if (e.Pressed.Contains(cfg.MasterToggleKey))
                Safe(_toggleMaster, "master");
            if (!cfg.Enabled)
                return; // остальное не активно при выключенном моде

            if (e.Pressed.Contains(cfg.RouteToggleKey)) Safe(_toggleRoute, "route");
            if (e.Pressed.Contains(cfg.AutoFishingToggleKey)) Safe(_toggleAutoFishing, "autofish");
            if (e.Pressed.Contains(cfg.PerfectFishingToggleKey)) Safe(_togglePerfect, "perfect");
            if (e.Pressed.Contains(cfg.TreasureToggleKey)) Safe(_cycleTreasure, "treasure");
            if (e.Pressed.Contains(cfg.NextTargetKey)) Safe(_nextTarget, "target");
        }

        private static void Safe(Action action, string name)
        {
            try
            {
                action();
            }
            catch (Exception ex)
            {
                Log.Error($"hotkey '{name}' handler failed", ex);
            }
        }
    }
}
