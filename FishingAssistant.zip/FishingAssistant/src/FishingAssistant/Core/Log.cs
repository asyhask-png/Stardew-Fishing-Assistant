using System;
using System.Collections.Generic;
using StardewModdingAPI;

namespace FishingAssistant.Core
{
    /// <summary>Централизованный лог и журнал действий мода.</summary>
    public static class Log
    {
        private static IMonitor _monitor;

        /// <summary>Включается из конфигурации (DebugLogging).</summary>
        public static bool DebugEnabled;

        /// <summary>Журнал удалённых фильтром предметов за сессию (для консольной команды fa_log).</summary>
        public static readonly List<string> SessionJournal = new List<string>();

        /// <summary>Инициализация логгера.</summary>
        public static void Init(IMonitor monitor) => _monitor = monitor;

        /// <summary>Обычное информационное сообщение (всегда пишется).</summary>
        public static void Info(string message) => _monitor?.Log(message, LogLevel.Info);

        /// <summary>Предупреждение (всегда пишется).</summary>
        public static void Warn(string message) => _monitor?.Log(message, LogLevel.Warn);

        /// <summary>Ошибка (всегда пишется).</summary>
        public static void Error(string message, Exception ex = null) => _monitor?.Log(message + (ex == null ? "" : $"\n{ex}"), LogLevel.Error);

        /// <summary>Диагностика — пишется только при DebugLogging = true.</summary>
        public static void Debug(string message)
        {
            if (DebugEnabled) _monitor?.Log("[debug] " + message, LogLevel.Trace);
        }

        /// <summary>Добавляет запись в журнал сессии.</summary>
        public static void Journal(string entry)
        {
            SessionJournal.Add($"[{DateTime.Now:HH:mm:ss}] {entry}");
            if (SessionJournal.Count > 200)
                SessionJournal.RemoveAt(0);
        }
    }
}
