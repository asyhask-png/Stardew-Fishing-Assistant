using System;
using System.Linq;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Menus;
using StardewValley.Tools;
using SObject = StardewValley.Object;

namespace FishingAssistant.Core
{
    /// <summary>Проверки состояния игры и мелкие игровые операции.</summary>
    public static class GameHelper
    {
        private readonly static char[] Sep = { ',' };

        /// <summary>Текущий мод-хелпер для переводов.</summary>
        public static IModHelper Helper;

        /// <summary>Локализованный текст.</summary>
        public static string T(string key, object tokens = null)
            => Helper == null ? key : Helper.Translation.Get(key, tokens);

        /// <summary>Показывает локальное HUD-сообщение (не отправляется другим игрокам).</summary>
        public static void NotifyHud(string text)
        {
            if (string.IsNullOrEmpty(text) || !Context.IsWorldReady)
                return;
            try { Game1.addHUDMessage(new HUDMessage(text)); }
            catch (Exception ex) { Log.Debug("HUD fail: " + ex.Message); }
        }

        /// <summary>Уведомляет и в HUD, и в лог.</summary>
        public static void Notify(string translationKey, object tokens = null)
        {
            string text = T(translationKey, tokens);
            NotifyHud(text);
            Log.Debug(text);
        }

        /// <summary>Может ли игрок сейчас действовать (нет меню/событий/диалогов).</summary>
        public static bool IsPlayerFree()
        {
            if (!Context.IsWorldReady || !Game1.player.CanMove || Game1.eventUp)
                return false;
            if (Game1.dialogueUp || Game1.activeClickableMenu is DialogueBox)
                return false;
            if (Game1.activeClickableMenu != null && !(Game1.activeClickableMenu is BobberBar))
                return false;
            return true;
        }

        /// <summary>Причина блокировки автоматизации или null.</summary>
        public static string BlockingReason()
        {
            if (!Context.IsWorldReady) return "world-not-ready";
            if (Game1.eventUp) return "event";
            if (Game1.dialogueUp || Game1.activeClickableMenu is DialogueBox) return "dialogue";
            if (Game1.activeClickableMenu != null && !(Game1.activeClickableMenu is BobberBar))
                return "menu:" + Game1.activeClickableMenu.GetType().Name;
            return null;
        }

        /// <summary>Активная планка мини-игры или null.</summary>
        public static BobberBar ActiveBobberBar => Game1.activeClickableMenu as BobberBar;

        /// <summary>Удочка в руках игрока или null.</summary>
        public static FishingRod EquippedRod => Game1.player?.CurrentTool as FishingRod;

        /// <summary>Число свободных слотов инвентаря (пустые ячейки; частично заполненные стакы не считаются местом для улова).</summary>
        public static int FreeInventorySlots()
        {
            var items = Game1.player.Items;
            int free = 0;
            for (int i = 0; i < items.Count; i++)
                if (items[i] == null)
                    free++;
            return free;
        }

        /// <summary>true — в инвентаре есть хотя бы один пустой слот для нового улова.</summary>
        public static bool HasRoomForCatch() => FreeInventorySlots() > 0;

        /// <summary>Парсит цвет из "#RRGGBB" или "R,G,B".</summary>
        public static Color ParseColor(string raw, Color fallback)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(raw)) return fallback;
                raw = raw.Trim();
                if (raw.StartsWith("#")) raw = raw.Substring(1);
                if (raw.Contains(","))
                {
                    var p = raw.Split(Sep, StringSplitOptions.RemoveEmptyEntries)
                               .Select(s => int.Parse(s.Trim())).ToArray();
                    if (p.Length >= 3) return new Color(p[0], p[1], p[2]);
                    return fallback;
                }
                if (raw.Length == 6 && int.TryParse(raw.Substring(0, 2), System.Globalization.NumberStyles.HexNumber, null, out int r))
                {
                    int g = int.Parse(raw.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
                    int b = int.Parse(raw.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);
                    return new Color(r, g, b);
                }
            }
            catch { }
            return fallback;
        }
    }
}
