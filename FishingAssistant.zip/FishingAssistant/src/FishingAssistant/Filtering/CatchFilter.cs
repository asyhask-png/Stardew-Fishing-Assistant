using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Objects;
using FishingAssistant.Core;
using FishingAssistant.Pure;
using SObject = StardewValley.Object;

namespace FishingAssistant.Filtering
{
    /// <summary>
    /// Фильтр пойманной рыбы. Проверяет только новый улов текущей сессии авторыбалки
    /// (окно после завершения мини-игры), ранее лежавшие в инвентаре предметы не трогает.
    /// Встроенные защиты реализованы в <see cref="CatchRuleSet"/>.
    /// </summary>
    public class CatchFilter
    {
        private readonly Func<ModConfig> _config;

        private DateTime _windowUntil = DateTime.MinValue;
        private bool _treasurePending;

        /// <summary>Создаёт фильтр.</summary>
        public CatchFilter(Func<ModConfig> config) => _config = config;

        /// <summary>Мини-игра успешно завершилась — открыть окно проверки улова.</summary>
        public void OnCatchLanded()
        {
            _windowUntil = DateTime.UtcNow.AddSeconds(6);
        }

        /// <summary>В этой рыбалке ожидается сокровище — его предмет не трогаем.</summary>
        public void MarkTreasurePending() => _treasurePending = true;

        /// <summary>Сброс между сессиями.</summary>
        public void Reset()
        {
            _windowUntil = DateTime.MinValue;
            _treasurePending = false;
        }

        /// <summary>Обработчик Player.InventoryChanged.</summary>
        public void OnInventoryChanged(object sender, InventoryChangedEventArgs e)
        {
            var cfg = _config();
            if (!cfg.Enabled || cfg.FishFilterMode == FishFilterMode.Off)
                return;
            var added = e.Added?.ToList();
            if (added == null || added.Count == 0)
                return;
            if (DateTime.UtcNow > _windowUntil)
            {
                _treasurePending = false; // окно закрыто — сбрасываем признак сокровища
                return;                   // это не новый улов нашей рыбалки
            }

            foreach (var item in e.Added)
                Inspect(item, cfg);
        }

        /// <summary>Проверяет один добавленный предмет.</summary>
        private void Inspect(Item item, ModConfig cfg)
        {
            if (item == null)
                return;

            var info = Describe(item);
            var decision = CatchRuleSet.Evaluate(info, ToSettings(cfg));

            Log.Debug($"filter: {info.QualifiedItemId} '{info.DisplayName}' q={info.Quality} fish={info.IsFish} → {decision.Kind} ({decision.Reason})");

            switch (decision.Kind)
            {
                case FilterDecisionKind.Keep:
                    return;

                case FilterDecisionKind.ProtectedKeep:
                    if (decision.Reason is "legendary" or "quest")
                        Log.Journal($"PROTECTED kept: {info.DisplayName} ({info.QualifiedItemId})");
                    return;

                case FilterDecisionKind.Trash:
                    ApplyTrash(item, cfg, info, decision.Reason);
                    break;
            }
        }

        private void ApplyTrash(Item item, ModConfig cfg, CatchInfo info, string reason)
        {
            string name = string.IsNullOrEmpty(info.DisplayName) ? info.QualifiedItemId : info.DisplayName;

            switch (cfg.FishFilterBehavior)
            {
                case FilteredItemBehavior.Remove:
                    RemoveFromInventory(item);
                    GameHelper.Notify("filter.trashed", new { name, reason });
                    Log.Journal($"TRASHED (remove): {name} [{info.QualifiedItemId}] q={info.Quality}, reason={reason}");
                    break;

                case FilteredItemBehavior.DropNearby:
                    if (!info.CannotBeTrashed && TryDropNearby(item))
                    {
                        GameHelper.Notify("filter.dropped", new { name, reason });
                        Log.Journal($"DROPPED: {name} [{info.QualifiedItemId}] q={info.Quality}, reason={reason}");
                    }
                    else
                    {
                        RemoveFromInventory(item);
                        GameHelper.Notify("filter.trashed", new { name, reason });
                        Log.Journal($"TRASHED (drop-fail→remove): {name}, reason={reason}");
                    }
                    break;

                default: // NotifyOnly
                    GameHelper.Notify("filter.notify", new { name, reason });
                    Log.Journal($"NOTIFIED: {name}, reason={reason}");
                    break;
            }
        }

        private static bool RemoveFromInventory(Item item)
        {
            try
            {
                var items = Game1.player.Items;
                for (int i = 0; i < items.Count; i++)
                {
                    if (ReferenceEquals(items[i], item))
                    {
                        items[i] = null;
                        Game1.playSound("trashcan");
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Debug("remove fail: " + ex.Message);
            }
            return false;
        }

        private static bool TryDropNearby(Item item)
        {
            try
            {
                Vector2 pos = Game1.player.Position + new Vector2(32f, 32f);
                Debris d = Game1.createItemDebris(item, pos, Game1.player.FacingDirection, Game1.currentLocation);
                return d != null;
            }
            catch (Exception ex)
            {
                Log.Debug("drop fail: " + ex.Message);
                return false;
            }
        }

        /// <summary>Собирает описание предмета для движка правил.</summary>
        public CatchInfo Describe(Item item)
        {
            var info = new CatchInfo
            {
                ItemId = Safe(() => item.ItemId),
                QualifiedItemId = Safe(() => item.QualifiedItemId),
                DisplayName = Safe(() => item.DisplayName),
                Category = Safe(() => item.Category),
                Quality = Math.Clamp(Safe(() => item.Quality), 0, 4),
            };

            // рыба?
            info.IsFish = info.Category == -4 || IsInFishData(info.ItemId);

            // легендарная?
            try { info.IsLegendary = item.HasContextTag("fish_legendary"); }
            catch { /* старые версии без тегов */ }

            // квестовые/особые
            try
            {
                if (item is SObject obj)
                {
                    info.IsQuestOrSpecial |= obj.questItem.Value;
                    info.IsQuestOrSpecial |= !string.IsNullOrEmpty(obj.questId.Value);
                }
            }
            catch { }
            try { info.IsQuestOrSpecial |= item.specialItem; } catch { }
            try { info.CannotBeTrashed = !item.canBeTrashed(); } catch { info.CannotBeTrashed = true; }

            info.FromTreasure = _treasurePending;
            info.UnknownType = !info.IsFish && !HasKnownCategory(info.Category);

            return info;
        }

        private static bool HasKnownCategory(int category)
            => category == -4   // рыбы
            || category == -20  // квестовые
            || category == -21  // мусор
            || category == -23; // водоросли/трофеи

        private static T Safe<T>(Func<T> f)
        {
            try { return f(); } catch { return default; }
        }

        private static bool IsInFishData(string itemId)
        {
            if (string.IsNullOrEmpty(itemId)) return false;
            try
            {
                var data = Game1.content.Load<Dictionary<string, string>>(@"Data\Fish");
                return data.ContainsKey(itemId);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Снимает чистые настройки фильтра из конфигурации.</summary>
        public static FilterSettings ToSettings(ModConfig cfg)
        {
            return new FilterSettings
            {
                Mode = cfg.FishFilterMode,
                MinQuality = (int)cfg.MinimumQuality,
                MaxQuality = (int)cfg.MaximumQuality,
                Allowed = new HashSet<string>(cfg.AllowedFish ?? new List<string>(), StringComparer.OrdinalIgnoreCase),
                Blocked = new HashSet<string>(cfg.BlockedFish ?? new List<string>(), StringComparer.OrdinalIgnoreCase),
                Protected = new HashSet<string>(cfg.ProtectedFish ?? new List<string>(), StringComparer.OrdinalIgnoreCase),
            };
        }

        /// <summary>Разрешает названия рыбы в ID через Data/Fish (для диагностики конфигурации).</summary>
        public static Dictionary<string, string> ResolveNameMap()
        {
            var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                var data = Game1.content.Load<Dictionary<string, string>>(@"Data\Fish");
                foreach (var kv in data)
                {
                    string[] parts = kv.Value.Split('/');
                    if (parts.Length > 0 && !map.ContainsKey(parts[0]))
                        map[parts[0]] = kv.Key;
                }
            }
            catch { }
            return map;
        }
    }
}
