using StardewModdingAPI;

namespace FishingAssistant
{
    /// <summary>Режим сбора сокровищ в мини-игре.</summary>
    public enum TreasureMode
    {
        /// <summary>Игнорировать сундуки с сокровищами.</summary>
        Off = 0,
        /// <summary>Идти к сундуку только при низком риске потерять рыбу.</summary>
        SafeOnly = 1,
        /// <summary>Пытаться собрать сокровище при любой возможности.</summary>
        AlwaysTry = 2,
    }

    /// <summary>Режим фильтра улова.</summary>
    public enum FishFilterMode
    {
        /// <summary>Фильтр выключен.</summary>
        Off = 0,
        /// <summary>Оставлять только перечисленную рыбу (белый список).</summary>
        Whitelist = 1,
        /// <summary>Выбрасывать перечисленную рыбу (чёрный список).</summary>
        Blacklist = 2,
    }

    /// <summary>Что делать с уловом, не прошедшим фильтр.</summary>
    public enum FilteredItemBehavior
    {
        /// <summary>Тихо удалить из инвентаря.</summary>
        Remove = 0,
        /// <summary>Выбросить на землю рядом с игроком, если предмет можно выбросить.</summary>
        DropNearby = 1,
        /// <summary>Ничего не делать, только показать уведомление.</summary>
        NotifyOnly = 2,
    }

    /// <summary>Порог качества для фильтра.</summary>
    public enum QualityGate
    {
        Any = 0,
        Silver = 1,
        Gold = 2,
        Iridium = 4,
    }

    /// <summary>Как выбирать целевое пузырьковое место.</summary>
    public enum TargetSelectionMode
    {
        /// <summary>Ближайшее по длине маршрута.</summary>
        NearestByRoute = 0,
        /// <summary>В приоритете пузырьки из текущей локации.</summary>
        CurrentLocationFirst = 1,
        /// <summary>Ручной выбор клавишей NextTargetKey по кругу.</summary>
        Manual = 2,
    }

    /// <summary>Типы специальных рыболовных точек.</summary>
    [System.Flags]
    public enum BubbleKinds
    {
        /// <summary>Обычные пузырьки (fishSplashPoint).</summary>
        Splash = 1,
        /// <summary>Рыбный угар / Fish Frenzy (fishFrenzyFish непустой; радиус больше).</summary>
        FishFrenzy = 2,
    }
}
