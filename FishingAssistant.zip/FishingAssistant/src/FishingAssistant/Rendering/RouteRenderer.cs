﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewValley;
using FishingAssistant.Routing;
using FishingAssistant.Core;

namespace FishingAssistant.Rendering
{
    /// <summary>
    /// Рисует яркий маршрут к пузырькам: штриховая анимированная линия по проходимым клеткам,
    /// маркер цели и подсветку перехода. Не рисует во время меню, событий и кат-сцен.
    /// </summary>
    public class RouteRenderer
    {
        private readonly Func<ModConfig> _config;
        private readonly Func<List<Routing.RouteLeg>> _routeProvider;
        private Texture2D _pixel;
        private long _animMs;

        /// <summary>Создаёт рендерер.</summary>
        public RouteRenderer(Func<ModConfig> config, Func<List<Routing.RouteLeg>> routeProvider)
        {
            _config = config;
            _routeProvider = routeProvider;
        }

        /// <summary>Отрисовка (подписывается на Display.RenderedWorld).</summary>
        public void Draw(object sender, StardewModdingAPI.Events.RenderedWorldEventArgs e)
        {
            var cfg = _config();
            if (!cfg.Enabled || !cfg.RouteEnabled || e.SpriteBatch == null)
                return;

            // не рисуем в меню/событиях/кат-сценаx
            if (!Context.IsWorldReady || Game1.eventUp)
                return;
            if (Game1.activeClickableMenu != null)
                return;

            try
            {
                var legs = _routeProvider();
                if (legs == null || legs.Count == 0)
                    return;

                if (_pixel == null || _pixel.IsDisposed)
                    _pixel = new Texture2D(e.SpriteBatch.GraphicsDevice, 1, 1);
                _pixel.SetData(new[] { Color.White });

                string here = Game1.currentLocation?.Name;
                RouteLeg leg = null;
                foreach (var l in legs)
                    if (l.LocationName.Equals(here, StringComparison.OrdinalIgnoreCase)) { leg = l; break; }
                if (leg == null)
                    return;

                Color baseColor = GameHelper.ParseColor(cfg.RouteColor, Color.SpringGreen) * Math.Clamp(cfg.RouteOpacity, 0f, 1f);
                float thickness = Math.Max(1f, cfg.RouteThickness);

                // точки в мировых координатах: старт — центр игрока
                var points = new List<Vector2>();
                if (leg.Points.Count > 0 && leg.Exit == null)
                {
                    // финальная часть: игрок → берег
                    points.Add(Game1.player.Position + new Vector2(32f, 48f));
                    foreach (var p in leg.Points)
                        points.Add(TileCenter(p.x, p.y));
                }
                else
                {
                    points.Add(Game1.player.Position + new Vector2(32f, 48f));
                    foreach (var p in leg.Points)
                        points.Add(TileCenter(p.x, p.y));
                }

                if (points.Count < 2)
                    return;

                _animMs = Environment.TickCount64;
                float dashOffset = cfg.RouteAnimated ? (_animMs % 800) / 800f * 48f : 0f;

                for (int i = 0; i < points.Count - 1; i++)
                    DrawDashedSegment(e.SpriteBatch, points[i], points[i + 1], baseColor, thickness, dashOffset);

                // стрелка на конце
                DrawArrowHead(e.SpriteBatch, points[points.Count - 2], points[points.Count - 1], baseColor, thickness * 3.2f);

                // маркер воды-цели
                if (leg.WaterTarget.HasValue)
                {
                    var c = TileCenter(leg.WaterTarget.Value.x, leg.WaterTarget.Value.y);
                    float pulse = 6f + 3f * (float)Math.Sin(_animMs / 180.0);
                    DrawCircle(e.SpriteBatch, c, 26f + pulse, baseColor, 3f);
                }

                // подсветка перехода на другую локацию
                if (leg.Exit != null)
                {
                    var c = TileCenter(leg.Exit.FromX, leg.Exit.FromY);
                    DrawCircle(e.SpriteBatch, c, 30f, Color.Gold * 0.9f, 4f);
                }
            }
            catch (Exception ex)
            {
                Log.Debug("RouteRenderer draw failed: " + ex.Message);
            }
        }

        private static Vector2 TileCenter(int tx, int ty) => new Vector2(tx * 64f + 32f, ty * 64f + 32f);

        private void DrawDashedSegment(SpriteBatch sb, Vector2 a, Vector2 b, Color color, float thickness, float dashOffsetPx)
        {
            float len = Vector2.Distance(a, b);
            if (len < 1f) return;
            var dir = (b - a) / len;
            const float dash = 24f, gap = 24f;
            float pos = -dashOffsetPx % (dash + gap);
            while (pos < len)
            {
                float s = Math.Max(0f, pos);
                float t = Math.Min(len, pos + dash);
                if (t > s)
                    DrawLine(sb, a + dir * s, a + dir * t, color, thickness);
                pos += dash + gap;
            }
        }

        private void DrawLine(SpriteBatch sb, Vector2 a, Vector2 b, Color color, float thickness)
        {
            var delta = b - a;
            float angle = (float)Math.Atan2(delta.Y, delta.X);
            float length = delta.Length();
            sb.Draw(
                _pixel,
                Game1.GlobalToLocal(Game1.viewport, a),
                null,
                color,
                angle,
                new Vector2(0f, 0.5f),
                new Vector2(length, thickness),
                SpriteEffects.None,
                0.9999f);
        }

        private void DrawArrowHead(SpriteBatch sb, Vector2 from, Vector2 tip, Color color, float size)
        {
            var dir = tip - from;
            if (dir.LengthSquared() < 1f) dir = new Vector2(0, -1);
            dir.Normalize();

            var left = new Vector2(-dir.Y, dir.X);
            var p1 = tip;
            var p2 = tip - dir * size + left * size * 0.55f;
            var p3 = tip - dir * size - left * size * 0.55f;
            FillTriangle(sb, p1, p2, p3, color, size);
        }

        /// <summary>Заполненный треугольник полосками (без шейдеров).</summary>
        private void FillTriangle(SpriteBatch sb, Vector2 p1, Vector2 p2, Vector2 p3, Color color, float step)
        {
            var minY = Math.Min(p1.Y, Math.Min(p2.Y, p3.Y));
            var maxY = Math.Max(p1.Y, Math.Max(p2.Y, p3.Y));
            for (float y = minY; y <= maxY; y += Math.Max(2f, step / 8f))
            {
                var xs = new List<float>();
                AddX(xs, p1, p2, y); AddX(xs, p2, p3, y); AddX(xs, p3, p1, y);
                if (xs.Count >= 2)
                {
                    xs.Sort();
                    var a = new Vector2(xs[0], y);
                    var b = new Vector2(xs[xs.Count - 1], y);
                    DrawLine(sb, a, b, color, Math.Max(2f, step / 8f));
                }
            }
        }

        private static void AddX(List<float> xs, Vector2 a, Vector2 b, float y)
        {
            if ((a.Y <= y && b.Y >= y) || (a.Y >= y && b.Y <= y))
            {
                if (Math.Abs(b.Y - a.Y) < 0.001f)
                {
                    xs.Add(a.X);
                }
                else
                {
                    float t = (y - a.Y) / (b.Y - a.Y);
                    xs.Add(a.X + (b.X - a.X) * t);
                }
            }
        }

        private void DrawCircle(SpriteBatch sb, Vector2 center, float radius, Color color, float thickness)
        {
            const int segments = 20;
            var prev = center + new Vector2(radius, 0);
            for (int i = 1; i <= segments; i++)
            {
                double a = Math.PI * 2 * i / segments;
                var next = center + new Vector2((float)(radius * Math.Cos(a)), (float)(radius * Math.Sin(a)));
                DrawLine(sb, prev, next, color, thickness);
                prev = next;
            }
        }
    }
}

