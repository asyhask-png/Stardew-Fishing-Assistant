using System;
using System.Collections.Generic;
using StardewModdingAPI;

namespace FishingAssistant
{
    /// <summary>Типизированная конфигурация мода. Файл config.json создаётся автоматически.</summary>
    public class ModConfig
    {
        /// <summary>Полное включение/отключение мода.</summary>
        public bool Enabled { get; set; } = true;

        // --- Модули ---
        /// <summary>Обнаружение пузырьковых мест.</summary>
        public bool BubbleDetectionEnabled { get; set; } = true;

        /// <summary>HUD-уведомления о новых пузырьках.</summary>
        public bool BubbleNotificationsEnabled { get; set; } = true;

        /// <summary>Какие типы точек отслеживать: Splash, FishFrenzy или оба (флаги).</summary>
        public BubbleKinds TrackedBubbleKinds { get; set; } = BubbleKinds.Splash | BubbleKinds.FishFrenzy;

        /// <summary>Визуальный маршрут к цели.</summary>
        public bool RouteEnabled { get; set; } = true;

        /// <summary>Автоматическая рыбалка (заброс, подсечка, цикл).</summary>
        public bool AutoFishingEnabled { get; set; } = false;

        /// <summary>Автоматическая мини-игра (идеальное ведение планки).</summary>
        public bool PerfectFishingEnabled { get; set; } = false;

        /// <summary>Режим сбора сокровищ (Off / SafeOnly / AlwaysTry).</summary>
        public TreasureMode TreasureMode { get; set; } = TreasureMode.Off;

        /// <summary>Автозаброс работает и без пузырьков (выбирается лучшая вода).</summary>
        public AutoCastWithoutBubbles AutoCastWithoutBubbles { get; set; } = AutoCastWithoutBubbles.Enabled;

        // --- Фильтр улова ---
        /// <summary>Фильтр пойманной рыбы.</summary>
        public FishFilterMode FishFilterMode { get; set; } = FishFilterMode.Off;

        /// <summary>Что делать с уловом вне правил: Remove / DropNearby / NotifyOnly.</summary>
        public FilteredItemBehavior FishFilterBehavior { get; set; } = FilteredItemBehavior.NotifyOnly;

        /// <summary>Минимальное качество оставляемой рыбы.</summary>
        public QualityGate MinimumQuality { get; set; } = QualityGate.Any;

        /// <summary>Максимальное качество оставляемой рыбы (в чёрном списке — выбрасываемой).</summary>
        public QualityGate MaximumQuality { get; set; } = QualityGate.Iridium;

        /// <summary>Белый список: ID или названия рыбы (пусто = не ограничивать).</summary>
        public List<string> AllowedFish { get; set; } = new List<string>();

        /// <summary>Чёрный список: ID или названия рыбы.</summary>
        public List<string> BlockedFish { get; set; } = new List<string>();

        /// <summary>Защищённые ID/названия, которые фильтр никогда не трогает (кроме встроенных защит).</summary>
        public List<string> ProtectedFish { get; set; } = new List<string>();

        // --- Выбор цели ---
        /// <summary>Стратегия выбора пузырькового места.</summary>
        public TargetSelectionMode TargetSelection { get; set; } = TargetSelectionMode.CurrentLocationFirst;

        // --- Горячие клавиши ---
        /// <summary>Мгновенное включение/отключение всего мода.</summary>
        public SButton MasterToggleKey { get; set; } = SButton.F6;

        /// <summary>Показать/скрыть маршрут.</summary>
        public SButton RouteToggleKey { get; set; } = SButton.F7;

        /// <summary>Включить/выключить авторыбалку.</summary>
        public SButton AutoFishingToggleKey { get; set; } = SButton.F8;

        /// <summary>Включить/выключить идеальную мини-игру.</summary>
        public SButton PerfectFishingToggleKey { get; set; } = SButton.F9;

        /// <summary>Переключить режим сокровищ по кругу Off → SafeOnly → AlwaysTry.</summary>
        public SButton TreasureToggleKey { get; set; } = SButton.F10;

        /// <summary>Следующее пузырьковое место (при Manual-режиме и не только).</summary>
        public SButton NextTargetKey { get; set; } = SButton.F11;

        // --- Внешний вид маршрута ---
        /// <summary>Цвет линии маршрута: "#RRGGBB" или "R,G,B".</summary>
        public string RouteColor { get; set; } = "#3CFF9E";

        /// <summary>Прозрачность линии 0..1.</summary>
        public float RouteOpacity { get; set; } = 0.85f;

        /// <summary>Толщина линии в пикселях мира.</summary>
        public float RouteThickness { get; set; } = 5f;

        /// <summary>Анимация штриховки линии.</summary>
        public bool RouteAnimated { get; set; } = true;

        // --- Авторыбалка ---
        /// <summary>Пауза между забросами, мс.</summary>
        public int RecastDelayMs { get; set; } = 800;

        /// <summary>Максимальное время ожидания поклёвки одного заброса, мс (0 = без лимита).</summary>
        public int BiteTimeoutMs { get; set; } = 0;

        // --- Идеальная мини-игра ---
        /// <summary>Допустимая погрешность удержания, пиксели шкалы.</summary>
        public float MinigameTolerancePx { get; set; } = 14f;

        /// <summary>Интенсивность корректировки 0.2..2.0 (множитель ускорения кнопки).</summary>
        public float MinigameStrength { get; set; } = 1f;

        /// <summary>Учитывать инерцию планки при торможении.</summary>
        public bool MinigameAnticipate { get; set; } = true;

        /// <summary>Аварийно отключать идеальную рыбалку при неизвестной структуре мини-игры.</summary>
        public bool MinigameSafeMode { get; set; } = true;

        // --- Прочее ---
        /// <summary>Предупреждать о возможных конфликтующих рыболовных модах и отключать авторыбалку.</summary>
        public bool RespectConflictingMods { get; set; } = true;

        /// <summary>Подробная диагностика в лог SMAPI.</summary>
        public bool DebugLogging { get; set; } = false;
    }

    /// <summary>Поведение автозаброса при отсутствии пузырьков.</summary>
    public enum AutoCastWithoutBubbles
    {
        /// <summary>Забрасывать в лучшую доступную воду.</summary>
        Enabled = 0,
        /// <summary>Ждать пузырьки.</summary>
        WaitBubbles = 1,
    }
}
