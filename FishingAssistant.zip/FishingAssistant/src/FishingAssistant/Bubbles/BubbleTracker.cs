﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using FishingAssistant.Core;
using FishingAssistant.Pure;

namespace FishingAssistant.Bubbles
{
    /// <summary>
    /// Отслеживает пузырьковые места по официальным полям игры:
    /// <see cref="StardewValley.GameLocation.fishSplashPoint"/> и <see cref="StardewValley.GameLocation.fishFrenzyFish"/>.
    /// Декоративная анимация воды игнорируется — читается только авторитетное состояние локации.
    /// Сканирование выполняется раз в секунду, а не каждый кадр.
    /// </summary>
    public class BubbleTracker
    {
        private readonly Func<ModConfig> _config;
        private readonly Dictionary<string, BubbleTarget> _active = new Dictionary<string, BubbleTarget>();
        private readonly HashSet<string> _notified = new HashSet<string>();

        /// <summary>Новое место обнаружено.</summary>
        public event Action<BubbleTarget> Discovered;

        /// <summary>Место исчезло.</summary>
        public event Action<BubbleTarget> Lost;

        /// <summary>Текущие известные места (снимок).</summary>
        public List<BubbleTarget> Active => _active.Values.ToList();

        /// <summary>Создаёт трекер.</summary>
        public BubbleTracker(Func<ModConfig> config)
        {
            _config = config;
            Discovered += OnDiscoveredNotify;
        }

        /// <summary>Полный сброс (смена дня, загрузка сохранения).</summary>
        public void Reset()
        {
            foreach (var t in _active.Values)
                Lost?.Invoke(t);
            _active.Clear();
            Log.Debug("BubbleTracker reset");
        }

        /// <summary>Один проход сканирования всех загруженных локаций.</summary>
        public void Scan()
        {
            var cfg = _config();
            if (!cfg.Enabled || !cfg.BubbleDetectionEnabled)
                return;

            long now = Environment.TickCount64;
            var seen = new HashSet<string>();

            try
            {
                var locations = Game1.locations;
                if (locations == null)
                    return;

                foreach (var loc in locations)
                {
                    if (loc == null || loc.fishSplashPoint == null)
                        continue;

                    // fishFrenzyFish != "" ⇒ точка работает в режиме «рыбного угара»
                    bool frenzy = false;
                    try { frenzy = !string.IsNullOrEmpty(loc.fishFrenzyFish.Value); }
                    catch { /* поле может отсутствовать на модовых локациях-наследниках */ }

                    Point p = loc.fishSplashPoint.Value;
                    if (p == Point.Zero)
                        continue;

                    BubbleKind kind = frenzy ? BubbleKind.FishFrenzy : BubbleKind.Splash;
                    if ((cfg.TrackedBubbleKinds & (frenzy ? BubbleKinds.FishFrenzy : BubbleKinds.Splash)) == 0)
                        continue;

                    string key = $"{loc.Name}|{p.X}|{p.Y}|{kind}";
                    seen.Add(key);

                    if (_active.TryGetValue(key, out var existing))
                    {
                        existing.LastSeenMs = now;
                        continue;
                    }

                    var target = new BubbleTarget(loc.Name, p.X, p.Y, kind, now);
                    _active[key] = target;
                    Log.Debug($"bubble found: {target}");
                    Discovered?.Invoke(target);
                }
            }
            catch (Exception ex)
            {
                Log.Error("BubbleTracker scan failed", ex);
            }

            // удаляем устаревшие точки
            var gone = _active.Where(kv => !seen.Contains(kv.Key)).Select(kv => kv.Value).ToList();
            foreach (var t in gone)
            {
                _active.Remove(t.Key);
                Log.Debug($"bubble lost: {t}");
                Lost?.Invoke(t);
            }
        }

        private void OnDiscoveredNotify(BubbleTarget target)
        {
            var cfg = _config();
            if (cfg == null || !cfg.BubbleNotificationsEnabled || !Context.IsWorldReady)
                return;
            if (!_notified.Add(target.Key))
                return; // не спамим повторными сообщениями

            GameHelper.Notify("bubble.found", new
            {
                location = PrettyName(target.LocationName),
                x = target.X,
                y = target.Y,
                kind = target.Kind == BubbleKind.FishFrenzy ? GameHelper.T("bubble.kind.frenzy") : "",
            });
        }

        /// <summary>Дружелюбное имя локации для уведомлений.</summary>
        public static string PrettyName(string locationName)
        {
            try
            {
                var loc = Game1.getLocationFromName(locationName);
                string display = loc?.DisplayName;
                return string.IsNullOrWhiteSpace(display) ? locationName : display;
            }
            catch
            {
                return locationName;
            }
        }
    }
}

