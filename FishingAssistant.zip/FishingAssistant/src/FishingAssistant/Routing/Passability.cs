using System;
using Microsoft.Xna.Framework;
using StardewValley;
using FishingAssistant.Core;
using FishingAssistant.Pure;

namespace FishingAssistant.Routing
{
    /// <summary>Фабрика предикатов проходимости на основе реальных карт игры.</summary>
    public static class Passability
    {
        /// <summary>Границы карты.</summary>
        public static PassabilityPredicate InBounds(GameLocation loc)
        {
            int w = loc?.Map?.Layers?[0]?.LayerWidth ?? 0;
            int h = loc?.Map?.Layers?[0]?.LayerHeight ?? 0;
            return (x, y) => x >= 0 && y >= 0 && x < w && y < h;
        }

        /// <summary>Можно ли идти по клетке (не вода, нет коллизий построек).</summary>
        public static bool Walkable(GameLocation loc, int x, int y)
        {
            if (loc == null) return false;
            try
            {
                if (loc.isWaterTile(x, y))
                    return false;
                return loc.isTilePassable(new Vector2(x, y));
            }
            catch
            {
                // модовая карта с нестандартной структурой — считаем непроходимой
                return false;
            }
        }

        /// <summary>Является ли клетка водой, в которую можно забросить удочку.</summary>
        public static bool IsFishableWater(GameLocation loc, int x, int y)
        {
            try { return loc != null && loc.isWaterTile(x, y); }
            catch { return false; }
        }

        /// <summary>Открытая ли вода (для оценки «глубины» места).</summary>
        public static bool IsOpenWater(GameLocation loc, int x, int y)
        {
            try { return loc.isOpenWater(x, y); }
            catch { return false; }
        }

        /// <summary>Собирает предикаты для A* по локации.</summary>
        public static void MakeGrid(GameLocation loc,
            out PassabilityPredicate inBounds, out PassabilityPredicate walkable)
        {
            var location = loc;
            var bounds = InBounds(location);
            inBounds = bounds;
            walkable = (x, y) => bounds(x, y) && Walkable(location, x, y);
        }
    }
}
