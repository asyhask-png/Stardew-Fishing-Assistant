using System;
using System.Collections.Generic;
using System.Linq;
using StardewValley;
using FishingAssistant.Bubbles;
using FishingAssistant.Core;

namespace FishingAssistant.Routing
{
    /// <summary>Переход между локациями.</summary>
    public class WarpEdge
    {
        /// <summary>Локация-источник.</summary>
        public string From;

        /// <summary>Клетка выхода в локации-источнике.</summary>
        public int FromX, FromY;

        /// <summary>Локация-приёмник.</summary>
        public string To;

        /// <summary>Точка появления в локации-приёмнике.</summary>
        public int ToX, ToY;
    }

    /// <summary>
    /// Граф переходов между локациями: обычные warp'ы, двери зданий и лодка на Ginger Island.
    /// Строится один раз на день/сохранение и кешируется; полный поиск пути каждый тик не выполняется.
    /// </summary>
    public class LocationGraph
    {
        private Dictionary<string, List<WarpEdge>> _adjacency = new(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _knownLocations = new(StringComparer.OrdinalIgnoreCase);

        /// <summary>Ссылка на трекер пузырьков (для выбора цели по графу).</summary>
        public BubbleTracker Bubbles { get; set; }

        /// <summary>Известные локации (для диагностики).</summary>
        public IReadOnlyCollection<string> KnownLocations => _knownLocations;

        /// <summary>Полностью перестраивает граф из загруженных локаций.</summary>
        public void Rebuild()
        {
            var adj = new Dictionary<string, List<WarpEdge>>(StringComparer.OrdinalIgnoreCase);
            var known = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            try
            {
                foreach (GameLocation loc in Game1.locations)
                {
                    if (loc == null || string.IsNullOrEmpty(loc.Name))
                        continue;
                    known.Add(loc.Name);
                    if (!adj.TryGetValue(loc.Name, out var edges))
                        adj[loc.Name] = edges = new List<WarpEdge>();

                    // обычные варпы
                    foreach (var w in loc.warps)
                    {
                        if (w == null || string.IsNullOrEmpty(w.TargetName) || w.npcOnly.Value)
                            continue;
                        edges.Add(new WarpEdge
                        {
                            From = loc.Name,
                            FromX = w.X,
                            FromY = w.Y,
                            To = w.TargetName,
                            ToX = w.TargetX,
                            ToY = w.TargetY,
                        });
                    }

                    // двери зданий: клетка → интерьер
                    try
                    {
                        foreach (var pair in loc.doors.Pairs)
                        {
                            if (string.IsNullOrEmpty(pair.Value))
                                continue;
                            edges.Add(new WarpEdge
                            {
                                From = loc.Name,
                                FromX = pair.Key.X,
                                FromY = pair.Key.Y,
                                To = pair.Value,
                                ToX = 2,
                                ToY = 3, // стандартная точка появления внутри интерьера уточняется после перехода
                            });
                        }
                    }
                    catch { /* doors может отсутствовать у части типов */ }
                }

                // специальные переходы: лодка Beach ↔ IslandSouth (если остров открыт)
                if (Game1.MasterPlayer != null && Game1.MasterPlayer.hasOrWillReceiveMail("willyBoatFixed"))
                {
                    AddSpecial(adj, "Beach", "IslandSouth", 21, 56, 5, 11);
                }

                // обратные дуги: если A→B есть, а B→A нет — добавляем симметричную с приблизительной точкой
                foreach (var kv in adj.ToList())
                {
                    foreach (var e in kv.Value.ToList())
                    {
                        if (!adj.TryGetValue(e.To, out var back))
                            adj[e.To] = back = new List<WarpEdge>();
                        if (!known.Contains(e.To)) known.Add(e.To);

                        bool hasReverse = back.Any(b => b.To.Equals(e.From, StringComparison.OrdinalIgnoreCase));
                        if (!hasReverse && adj.ContainsKey(e.From))
                        {
                            back.Add(new WarpEdge
                            {
                                From = e.To,
                                FromX = e.ToX,
                                FromY = e.ToY,
                                To = e.From,
                                ToX = Math.Max(0, e.FromX),
                                ToY = Math.Max(0, e.FromY + 1), // обычно появление под выходом
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("LocationGraph rebuild failed", ex);
            }

            _adjacency = adj;
            _knownLocations.Clear();
            foreach (var k in known) _knownLocations.Add(k);
            Log.Debug($"LocationGraph rebuilt: {adj.Count} locations, {_adjacency.Values.Sum(l => l.Count)} edges");
        }

        private static void AddSpecial(
            Dictionary<string, List<WarpEdge>> adj,
            string from, string to, int fx, int fy, int tx, int ty)
        {
            if (!adj.TryGetValue(from, out var a)) adj[from] = a = new List<WarpEdge>();
            if (!adj.TryGetValue(to, out var b)) adj[to] = b = new List<WarpEdge>();
            if (!a.Any(e => e.To == to)) a.Add(new WarpEdge { From = from, FromX = fx, FromY = fy, To = to, ToX = tx, ToY = ty });
            if (!b.Any(e => e.From == to && e.To == from)) b.Add(new WarpEdge { From = to, FromX = tx, FromY = ty, To = from, ToX = fx + 1, ToY = fy + 1 });
        }

        /// <summary>Есть ли локация в графе.</summary>
        public bool Knows(string locationName) => _knownLocations.Contains(locationName);

        /// <summary>Исходящие переходы локации.</summary>
        public IReadOnlyList<WarpEdge> EdgesFrom(string locationName)
        {
            return _adjacency.TryGetValue(locationName, out var list) ? list : Array.Empty<WarpEdge>();
        }

        /// <summary>
        /// Кратчайшая цепочка переходов между локациями (BFS по числу переходов).
        /// Возвращает последовательность рёбер или null.
        /// </summary>
        public List<WarpEdge> RouteBetween(string from, string to)
        {
            if (from == null || to == null) return null;
            if (from.Equals(to, StringComparison.OrdinalIgnoreCase))
                return new List<WarpEdge>();

            var prev = new Dictionary<string, WarpEdge>(StringComparer.OrdinalIgnoreCase);
            var queue = new Queue<string>();
            var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { from };
            queue.Enqueue(from);

            while (queue.Count > 0)
            {
                string cur = queue.Dequeue();
                foreach (var edge in EdgesFrom(cur))
                {
                    if (edge.To == null || !visited.Add(edge.To))
                        continue;
                    prev[edge.To] = edge;
                    if (edge.To.Equals(to, StringComparison.OrdinalIgnoreCase))
                    {
                        // восстановление цепочки
                        var chain = new List<WarpEdge>();
                        string step = to;
                        while (prev.TryGetValue(step, out var e))
                        {
                            chain.Add(e);
                            step = e.From;
                        }
                        chain.Reverse();
                        return chain;
                    }
                    queue.Enqueue(edge.To);
                }
            }
            return null;
        }

        /// <summary>Число переходов до целевой локации (для эвристик); -1 — недостижимо.</summary>
        public int HopDistance(string from, string to)
        {
            var route = RouteBetween(from, to);
            return route?.Count ?? -1;
        }
    }
}
