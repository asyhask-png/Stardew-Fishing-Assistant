﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using FishingAssistant.Bubbles;
using FishingAssistant.Core;
using FishingAssistant.Pure;

namespace FishingAssistant.Routing
{
    /// <summary>Одна часть маршрута в пределах одной локации.</summary>
    public class RouteLeg
    {
        /// <summary>Имя локации части.</summary>
        public string LocationName;

        /// <summary>Точки пути (клетки).</summary>
        public List<(int x, int y)> Points = new List<(int x, int y)>();

        /// <summary>Переход, завершающий часть (null для финальной).</summary>
        public WarpEdge Exit;

        /// <summary>Финальная цель — клетка воды рядом с последней точкой.</summary>
        public (int x, int y)? WaterTarget;
    }

    /// <summary>
    /// Строит и кеширует маршрут от игрока до выбранного пузырькового места,
    /// при необходимости через несколько локаций. Пересчёт — только по событиям
    /// (переход игрока, смена цели/дня), не каждый тик.
    /// </summary>
    public class RouteManager
    {
        private readonly LocationGraph _graph = new LocationGraph();
        private readonly Func<ModConfig> _config;

        private List<RouteLeg> _legs;
        private string _targetKey;
        private long _lastRebuildMs;
        private (int x, int y) _lastPlayerTile;

        /// <summary>Индекс ручной цели (циклический выбор клавишей NextTargetKey).</summary>
        public int ManualIndex { get; set; }

        /// <summary>Доступ к графу локаций.</summary>
        public LocationGraph Graph => _graph;

        /// <summary>Создаёт менеджер маршрутов.</summary>
        public RouteManager(Func<ModConfig> config)
        {
            _config = config;
        }

        /// <summary>Сбрасывает кеш маршрута.</summary>
        public void Invalidate()
        {
            _legs = null;
            _targetKey = null;
            _lastPlayerTile = (-1, -1);
        }

        /// <summary>Перестраивает граф локаций и сбрасывает маршрут (новый день / загрузка).</summary>
        public void RebuildGraph()
        {
            _graph.Rebuild();
            Invalidate();
        }

        /// <summary>Выбирает целевое пузырьковое место согласно настройке.</summary>
        public BubbleTarget SelectTarget()
        {
            var all = Graph.Bubbles?.Active ?? new List<BubbleTarget>();
            if (all.Count == 0)
                return null;

            string here = Game1.currentLocation?.Name;
            var cfg = _config();
            switch (cfg.TargetSelection)
            {
                case TargetSelectionMode.CurrentLocationFirst:
                    return all.FirstOrDefault(t => t.LocationName.Equals(here, StringComparison.OrdinalIgnoreCase))
                        ?? NearestByRoute(all, here);

                case TargetSelectionMode.NearestByRoute:
                    return NearestByRoute(all, here);

                case TargetSelectionMode.Manual:
                    var ordered = all.OrderBy(t => t.Key, StringComparer.Ordinal).ToList();
                    return ordered[Math.Abs(ManualIndex) % ordered.Count];

                default:
                    return all[0];
            }
        }

        /// <summary>Подключает трекер пузырьков (вызывается один раз из ModEntry).</summary>
        public void AttachBubbles(BubbleTracker bubbles)
        {
            Graph.Bubbles = bubbles;
            bubbles.Lost += OnBubbleLost;
        }

        private void OnBubbleLost(BubbleTarget target)
        {
            if (_targetKey != null && _targetKey == target.Key)
                Invalidate();
        }

        /// <summary>Переключает ручную цель на следующее место.</summary>
        public BubbleTarget CycleManualTarget()
        {
            ManualIndex++;
            var cfg = _config();
            var prev = cfg.TargetSelection;
            try
            {
                _config().TargetSelection = TargetSelectionMode.Manual;
                var target = SelectTarget();
                if (target != null)
                    GameHelper.Notify("target.changed", new
                    {
                        location = BubbleTracker.PrettyName(target.LocationName),
                        x = target.X,
                        y = target.Y,
                    });
                else
                    GameHelper.Notify("target.none");
                return target;
            }
            finally
            {
                _config().TargetSelection = prev;
            }
        }

        private BubbleTarget NearestByRoute(List<BubbleTarget> all, string here)
        {
            BubbleTarget best = null;
            int bestCost = int.MaxValue;
            foreach (var t in all)
            {
                int cost;
                if (t.LocationName.Equals(here, StringComparison.OrdinalIgnoreCase))
                {
                    var p = Game1.player.TilePoint;
                    cost = Math.Abs(p.X - t.X) + Math.Abs(p.Y - t.Y);
                }
                else
                {
                    int hops = _graph.HopDistance(here, t.LocationName);
                    if (hops < 0) continue;
                    cost = 1000 * hops;
                }
                if (cost < bestCost)
                {
                    bestCost = cost;
                    best = t;
                }
            }
            return best ?? all[0];
        }

        /// <summary>
        /// Текущий маршрут (пересчитывается лениво и с троттлингом).
        /// </summary>
        public List<RouteLeg> GetRoute()
        {
            var cfg = _config();
            if (!cfg.Enabled || !cfg.RouteEnabled || !Context.IsWorldReady)
                return null;

            var target = SelectTarget();
            if (target == null)
                return null;

            var playerTile = (x: Game1.player.TilePoint.X, y: Game1.player.TilePoint.Y);
            bool tileChanged = playerTile != _lastPlayerTile;
            long now = Environment.TickCount64;

            if (_legs != null && _targetKey == target.Key && !tileChanged)
                return _legs;

            // не чаще раза в 400 мс при движении игрока
            if (_legs != null && _targetKey == target.Key && tileChanged && now - _lastRebuildMs < 400)
                return _legs;

            _lastRebuildMs = now;
            _lastPlayerTile = playerTile;
            _targetKey = target.Key;
            _legs = BuildRoute(target, playerTile);
            Log.Debug($"route built for {target}: legs={_legs?.Count ?? 0}");
            return _legs;
        }

        /// <summary>Строит полный маршрут до цели (внутри локации или через переходы).</summary>
        public List<RouteLeg> BuildRoute(BubbleTarget target, (int x, int y) playerTile)
        {
            try
            {
                string here = Game1.currentLocation?.Name;

                if (target.LocationName.Equals(here, StringComparison.OrdinalIgnoreCase))
                {
                    var single = BuildSingleLeg(here, playerTile, target);
                    return single == null ? null : new List<RouteLeg> { single };
                }

                var chain = _graph.RouteBetween(here, target.LocationName);
                if (chain == null)
                {
                    var partial = BuildPartialTowardExit(here, playerTile, target.LocationName);
                    GameHelper.Notify("route.unreachable", new { location = BubbleTracker.PrettyName(target.LocationName) });
                    return partial;
                }

                var legs = new List<RouteLeg>();
                var cur = here;
                var from = playerTile;

                foreach (var edge in chain)
                {
                    Passability.MakeGrid(Game1.getLocationFromName(cur), out var inB, out var walk);
                    var exitTile = (edge.FromX, edge.FromY);
                    var path = AStar.FindPath(inB, walk, from, exitTile);
                    if (path == null && edge.FromX > 0)
                        path = AStar.FindPath(inB, walk, from, (edge.FromX, edge.FromY + 1));

                    legs.Add(new RouteLeg
                    {
                        LocationName = cur,
                        Points = path ?? new List<(int x, int y)> { from },
                        Exit = edge,
                    });

                    cur = edge.To;
                    from = (edge.ToX, edge.ToY);

                    if (!TryGetLoadedLocation(cur, out _))
                    {
                        Log.Warn($"Route location '{cur}' is not loaded yet.");
                        break;
                    }
                }

                var lastLeg = BuildSingleLeg(cur, from, target);
                if (lastLeg != null)
                    legs.Add(lastLeg);
                return legs;
            }
            catch (Exception ex)
            {
                Log.Error("BuildRoute failed", ex);
                return null;
            }
        }

        private RouteLeg BuildSingleLeg(string locName, (int x, int y) from, BubbleTarget target)
        {
            var loc = Game1.getLocationFromName(locName);
            if (loc == null) return null;
            Passability.MakeGrid(loc, out var inB, out var walk);

            var shore = FindBestShoreTile(loc, inB, walk, target);
            if (shore == null)
            {
                return new RouteLeg
                {
                    LocationName = locName,
                    Points = new List<(int x, int y)> { from },
                    WaterTarget = (target.X, target.Y),
                };
            }

            var path = AStar.FindPath(inB, walk, from, shore.Value);
            return new RouteLeg
            {
                LocationName = locName,
                Points = path ?? new List<(int x, int y)> { from },
                WaterTarget = (target.X, target.Y),
            };
        }

        /// <summary>Ближайшая проходимая клетка берега рядом с пузырьками.</summary>
        public (int x, int y)? FindBestShoreTile(
            GameLocation loc,
            PassabilityPredicate inB,
            PassabilityPredicate walk,
            BubbleTarget target)
        {
            (int x, int y)? best = null;
            double bestScore = double.MaxValue;

            const int r = 6;
            for (int dx = -r; dx <= r; dx++)
            {
                for (int dy = -r; dy <= r; dy++)
                {
                    int x = target.X + dx, y = target.Y + dy;
                    if (!inB(x, y) || !walk(x, y)) continue;
                    if (!HasAdjacentWater(loc, x, y)) continue;

                    double d = dx * dx + dy * dy;
                    if (d < bestScore)
                    {
                        bestScore = d;
                        best = (x, y);
                    }
                }
            }
            return best;
        }

        private static bool HasAdjacentWater(GameLocation loc, int x, int y)
        {
            return Passability.IsFishableWater(loc, x + 1, y)
                || Passability.IsFishableWater(loc, x - 1, y)
                || Passability.IsFishableWater(loc, x, y + 1)
                || Passability.IsFishableWater(loc, x, y - 1);
        }

        /// <summary>Частичный маршрут: направление к выходу, ведущему ближе всего к цели.</summary>
        private List<RouteLeg> BuildPartialTowardExit(string here, (int x, int y) playerTile, string targetLoc)
        {
            try
            {
                WarpEdge bestEdge = null;
                int bestHops = int.MaxValue;
                foreach (var e in _graph.EdgesFrom(here))
                {
                    int h = _graph.HopDistance(e.To, targetLoc);
                    if (h >= 0 && h < bestHops)
                    {
                        bestHops = h;
                        bestEdge = e;
                    }
                }

                var leg = new RouteLeg { LocationName = here };
                if (bestEdge != null)
                {
                    Passability.MakeGrid(Game1.getLocationFromName(here), out var inB, out var walk);
                    leg.Points = AStar.FindPath(inB, walk, playerTile, (bestEdge.FromX, bestEdge.FromY))
                               ?? new List<(int x, int y)> { playerTile };
                    leg.Exit = bestEdge;
                    GameHelper.Notify("route.to.exit", new { location = BubbleTracker.PrettyName(targetLoc) });
                }
                else
                {
                    leg.Points = new List<(int x, int y)> { playerTile };
                }
                return new List<RouteLeg> { leg };
            }
            catch
            {
                return new List<RouteLeg>
                {
                    new RouteLeg { LocationName = here, Points = new List<(int x, int y)> { playerTile } },
                };
            }
        }

        private static bool TryGetLoadedLocation(string name, out GameLocation loc)
        {
            try
            {
                loc = Game1.getLocationFromName(name);
                return loc != null;
            }
            catch
            {
                loc = null;
                return false;
            }
        }
    }
}
