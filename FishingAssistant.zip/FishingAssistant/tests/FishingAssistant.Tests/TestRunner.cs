using System;
using System.Collections.Generic;
using System.Linq;
using FishingAssistant.Pure;

namespace FishingAssistant.Tests
{
    /// <summary>Лёгкий собственный тест-раннер (без внешних зависимостей).</summary>
    public static class TestRunner
    {
        private static int _passed, _failed;
        private static string _section = "";

        public static int Main()
        {
            Console.WriteLine("Fishing Assistant — unit tests for pure algorithms\n");

            Run("AStar", AStarTests);
            Run("CastScoring", CastScoringTests);
            Run("CatchRuleSet", FilterTests);
            Run("TreasureRiskModel", TreasureTests);
            Run("BarController", ControllerTests);
            Run("FsmTransitions", FsmTests);
            Run("BubbleTarget", ModelTests);

            Console.WriteLine($"\nRESULT: {_passed} passed, {_failed} failed");
            return _failed == 0 ? 0 : 1;
        }

        private static void Run(string name, Action suite)
        {
            _section = name;
            int p0 = _passed, f0 = _failed;
            try { suite(); }
            catch (Exception ex) { Fail("suite crashed: " + ex.Message); }
            Console.WriteLine($"  [{name}] {_passed - p0} passed, {_failed - f0} failed");
        }

        private static void Ok(bool cond, string what)
        {
            if (cond) { _passed++; }
            else { _failed++; Console.WriteLine($"    FAIL [{_section}] {what}"); }
        }

        private static void Fail(string what)
        {
            _failed++;
            Console.WriteLine($"    FAIL [{_section}] {what}");
        }

        // ------------------------------------------------------------------ A*

        private static void AStarTests()
        {
            PassabilityPredicate all = (_, _) => true;
            PassabilityPredicate bounds5 = (x, y) => x >= 0 && y >= 0 && x < 10 && y < 10;

            // прямой путь
            var p = AStar.FindPath(bounds5, all, (0, 0), (3, 0));
            Ok(p != null && p[0] == (0, 0) && p[^1] == (3, 0), "straight path endpoints");
            Ok(AStar.PathLength(p) == 3f, "straight path length");

            // обход стены
            PassabilityPredicate wall = (x, y) => !(x == 2 && y >= 0 && y <= 8);
            var d = AStar.FindPath(bounds5, wall, (0, 0), (4, 0));
            Ok(d != null, "detour found around vertical wall");
            Ok(d.All(t => wall(t.x, t.y)), "detour avoids wall cells");

            // недостижимо
            PassabilityPredicate sealed_ = (x, y) => x <= 2;
            Ok(AStar.FindPath(bounds5, sealed_, (0, 0), (8, 0)) == null, "unreachable returns null");

            // запрет срезания углов по диагонали: стена только справа от старта,
            // диагональный шаг в (1,1) должен быть запрещён и путь идёт через (0,1)
            PassabilityPredicate cornerWall = (x, y) => !(x == 1 && y == 0);
            var diag = AStar.FindPath(bounds5, cornerWall, (0, 0), (1, 1));
            Ok(diag != null, "target behind corner wall reachable");
            bool cutCorner = false;
            if (diag != null)
                for (int i = 1; i < diag.Count; i++)
                {
                    int dx = Math.Abs(diag[i].x - diag[i - 1].x), dy = Math.Abs(diag[i].y - diag[i - 1].y);
                    if (dx == 1 && dy == 1)
                    {
                        bool a = cornerWall(diag[i].x, diag[i - 1].y);
                        bool b = cornerWall(diag[i - 1].x, diag[i].y);
                        if (!a || !b) cutCorner = true;
                    }
                }
            Ok(!cutCorner, "no diagonal step squeezes between wall and edge");

            // цель за границей
            Ok(AStar.FindPath(bounds5, all, (0, 0), (-1, 5)) == null, "out-of-bounds goal rejected");

            // старт == цель
            var self = AStar.FindPath(bounds5, all, (2, 2), (2, 2));
            Ok(self is { Count: 1 }, "start==goal yields single-node path");
        }

        // ------------------------------------------------------------------ заброс

        private static void CastScoringTests()
        {
            Ok(CastScoring.MaxCastTiles(0) == 4, "max tiles lvl0 = 4");
            Ok(CastScoring.MaxCastTiles(1) == 5, "max tiles lvl1 = 5");
            Ok(CastScoring.MaxCastTiles(4) == 6, "max tiles lvl4 = 6");
            Ok(CastScoring.MaxCastTiles(8) == 7, "max tiles lvl8 = 7");
            Ok(CastScoring.MaxCastTiles(15) == 8, "max tiles lvl15 = 8");

            Ok(CastScoring.PowerForDistance(100f, 5) == 1f, "power capped at 1 beyond range");
            Ok(CastScoring.PowerForDistance(0.01f, 5) >= 0.08f, "power floor respected");

            var candidates = new List<CastCandidate>
            {
                new() { LandingX = 5, LandingY = 5, DistTiles = 3f, MissTiles = 2f, ExactHit = false },
                new() { LandingX = 7, LandingY = 7, DistTiles = 9f, MissTiles = 0f, ExactHit = true },
            };
            var best = CastScoring.Best(candidates, preferExact: true);
            Ok(best?.LandingX == 7, "exact bubble hit dominates scoring");

            var bestNoTarget = CastScoring.Best(candidates, preferExact: false);
            Ok(bestNoTarget?.LandingX == 7, "smaller miss wins when no exact available");

            Ok(CastScoring.Best(new List<CastCandidate>(), true) == null, "empty candidates -> null");
        }

        // ------------------------------------------------------------------ фильтр

        private static FilterSettings Settings(FishFilterMode mode, int minQ = 0,
            string[] allow = null, string[] block = null, string[] protect = null)
        {
            return new FilterSettings
            {
                Mode = mode,
                MinQuality = minQ,
                Allowed = new HashSet<string>(allow ?? Array.Empty<string>()),
                Blocked = new HashSet<string>(block ?? Array.Empty<string>()),
                Protected = new HashSet<string>(protect ?? Array.Empty<string>()),
            };
        }

        private static CatchInfo Fish(string qid = "(O)129", int quality = 0, int category = -4)
        {
            return new CatchInfo
            {
                ItemId = qid?.Replace("(O)", ""),
                QualifiedItemId = qid,
                DisplayName = "TestFish",
                Category = category,
                Quality = quality,
                IsFish = true,
            };
        }

        private static void FilterTests()
        {
            // встроенные защиты
            foreach (var legendary in new[] { "(O)159", "(O)160", "(O)163", "(O)682", "(O)775", "(O)901" })
                Ok(CatchRuleSet.Evaluate(Fish(legendry(legendary)), Settings(FishFilterMode.Blacklist, block: new[] { "*" })).Kind
                   == FilterDecisionKind.ProtectedKeep, $"legendary {legendary} never trashed");

            var quest = Fish("(O)128"); quest.Category = -20;
            Ok(CatchRuleSet.Evaluate(quest, Settings(FishFilterMode.Blacklist)).Kind == FilterDecisionKind.ProtectedKeep, "quest category protected");

            var noTrash = Fish();
            noTrash.CannotBeTrashed = true;
            Ok(CatchRuleSet.Evaluate(noTrash, Settings(FishFilterMode.Blacklist)).Kind == FilterDecisionKind.ProtectedKeep, "cannot-be-trashed protected");

            var treasure = Fish();
            treasure.FromTreasure = true;
            Ok(CatchRuleSet.Evaluate(treasure, Settings(FishFilterMode.Blacklist)).Kind == FilterDecisionKind.ProtectedKeep, "treasure item protected");

            var unknown = new CatchInfo { QualifiedItemId = "(O)???", Category = 999, IsFish = false };
            Ok(CatchRuleSet.Evaluate(unknown, Settings(FishFilterMode.Whitelist)).Kind == FilterDecisionKind.ProtectedKeep, "unknown type kept");

            var notFish = Fish(category: 12); notFish.IsFish = false;
            Ok(CatchRuleSet.Evaluate(notFish, Settings(FishFilterMode.Whitelist)).Kind == FilterDecisionKind.ProtectedKeep, "non-fish without rule kept");

            // белый список
            var wl = Settings(FishFilterMode.Whitelist, allow: new[] { "129", "136" });
            Ok(CatchRuleSet.Evaluate(Fish(), wl).Kind == FilterDecisionKind.Keep, "whitelist keeps listed");
            Ok(CatchRuleSet.Evaluate(Fish("(O)138"), wl).Kind == FilterDecisionKind.Trash, "whitelist trashes unlisted");

            // качество
            var goldOnly = Settings(FishFilterMode.Whitelist, minQ: 2, allow: new[] { "129" });
            Ok(CatchRuleSet.Evaluate(Fish(quality: 2), goldOnly).Kind == FilterDecisionKind.Keep, "gold passes min-quality");
            Ok(CatchRuleSet.Evaluate(Fish(quality: 1), goldOnly).Kind == FilterDecisionKind.Trash, "silver fails min-quality");

            var bl = Settings(FishFilterMode.Blacklist, block: new[] { "136" });
            Ok(CatchRuleSet.Evaluate(Fish("(O)136"), bl).Kind == FilterDecisionKind.Trash, "blacklist trashes listed");
            Ok(CatchRuleSet.Evaluate(Fish("(O)129"), bl).Kind == FilterDecisionKind.Keep, "blacklist keeps others");

            // пользовательская защита сильнее режима
            var prot = Settings(FishFilterMode.Blacklist, block: new[] { "129" }, protect: new[] { "129" });
            Ok(CatchRuleSet.Evaluate(Fish(), prot).Kind == FilterDecisionKind.ProtectedKeep, "user protection beats blacklist");

            // соответствие по имени и квалификатору
            var byName = Settings(FishFilterMode.Blacklist, block: new[] { "carp" });
            var carp = Fish("(O)138"); carp.DisplayName = "Carp";
            Ok(!CatchRuleSet.MatchesKey(carp, byName.Blocked) , "name matching is case-insensitive exact ('Carp' vs 'carp')");
            carp.DisplayName = "carp";
            Ok(CatchRuleSet.MatchesKey(carp, byName.Blocked), "name match works");
            Ok(CatchRuleSet.MatchesKey(Fish("(O)136"), new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "(O)136" }), "qualified id match");
        }

        private static string legendry(string _) => _; // читаемость теста выше

        // ------------------------------------------------------------------ сокровища

        private static MinigameSnapshot Snap(float progress, float fishErr, bool treasure = true,
            float chestProgress = 0f, bool caught = false)
        {
            return new MinigameSnapshot
            {
                FishPos = 300f,
                BarCenter = 300f + fishErr,
                BarHalf = 50f,
                Progress = progress,
                TreasurePresent = treasure,
                TreasurePos = 100f,
                TreasureCaught = caught,
                TreasureProgress = chestProgress,
                FishInBar = Math.Abs(fishErr) <= 50f,
            };
        }

        private static void TreasureTests()
        {
            Ok(TreasureRiskModel.Decide(Snap(0.8f, 2f), TreasureMode.Off, false) == MinigameGoal.HoldFish, "Off ignores chests");

            Ok(TreasureRiskModel.Decide(Snap(0.30f, 0f), TreasureMode.SafeOnly, false) == MinigameGoal.HoldFish,
               "SafeOnly waits for progress headroom");
            Ok(TreasureRiskModel.Decide(Snap(0.60f, 0f), TreasureMode.SafeOnly, false) == MinigameGoal.ChaseTreasure,
               "SafeOnly chases when safe");
            Ok(TreasureRiskModel.Decide(Snap(0.60f, 45f), TreasureMode.SafeOnly, false) == MinigameGoal.HoldFish,
               "SafeOnly refuses when fish near edge");

            Ok(TreasureRiskModel.Decide(Snap(0.10f, 0f), TreasureMode.AlwaysTry, false) == MinigameGoal.HoldFish,
               "AlwaysTry still saves fish at critical progress");
            Ok(TreasureRiskModel.Decide(Snap(0.35f, 0f), TreasureMode.AlwaysTry, false) == MinigameGoal.ChaseTreasure,
               "AlwaysTry chases above critical");

            Ok(TreasureRiskModel.Decide(Snap(0.8f, 0f, treasure: false), TreasureMode.SafeOnly, true) == MinigameGoal.HoldFish,
               "no chest -> hold fish");

            Ok(!TreasureRiskModel.ShouldAbortChase(Snap(0.7f, 0f, chestProgress: 0.5f), TreasureMode.SafeOnly),
               "chase continues while stable and present");
            Ok(TreasureRiskModel.ShouldAbortChase(Snap(0.7f, 48f, chestProgress: 0.5f), TreasureMode.SafeOnly),
               "abort chase when fish drifting to edge");
        }

        // ------------------------------------------------------------------ регулятор планки

        private static void ControllerTests()
        {
            // мёртвая зона: нет ускорения при малой ошибке и малой скорости
            Ok(BarController.ComputeAcceleration(300f, 0f, 305f, tolerancePx: 14f, strength: 1f, anticipate: false) == 0f,
               "deadzone produces no acceleration");

            // ошибка > 0 (планка ниже цели) → ускорение вверх (отрицательное)
            float up = BarController.ComputeAcceleration(340f, 0f, 300f, 14f, 1f, false);
            Ok(up < 0f, "positive error drives bar up");
            Ok(Math.Abs(up) > BarController.ButtonAccel * 0.99f, "default strength uses full button accel");

            // сила масштабируется
            float weak = BarController.ComputeAcceleration(340f, 0f, 300f, 14f, 0.4f, false);
            Ok(weak < 0f && Math.Abs(weak) < Math.Abs(up), "strength scales acceleration down");

            // предсказание торможения: летим к цели почти впритык → отпускаем
            float coast = BarController.ComputeAcceleration(310f, -3f, 300f, 6f, 1f, anticipate: true);
            Ok(coast == 0f, "anticipation releases before overshoot");

            // гашение остаточной скорости в зоне
            float damp = BarController.ComputeAcceleration(300f, 2f, 300f, 20f, 1f, anticipate: true);
            Ok(damp < 0f, "residual speed is damped inside deadzone");
        }

        // ------------------------------------------------------------------ автомат

        private static void FsmTests()
        {
            Ok(FsmTransitions.CanTransition(FishingState.Idle, FishingState.SelectingTarget), "Idle→SelectingTarget");
            Ok(FsmTransitions.CanTransition(FishingState.SelectingTarget, FishingState.PreparingCast), "SelectingTarget→PreparingCast");
            Ok(FsmTransitions.CanTransition(FishingState.Casting, FishingState.WaitingForBite), "Casting→WaitingForBite");
            Ok(FsmTransitions.CanTransition(FishingState.WaitingForBite, FishingState.Hooking), "WaitingForBite→Hooking");
            Ok(FsmTransitions.CanTransition(FishingState.Hooking, FishingState.FishingMinigame), "Hooking→Minigame");
            Ok(FsmTransitions.CanTransition(FishingState.FishingMinigame, FishingState.HandlingCatch), "Minigame→HandlingCatch");
            Ok(FsmTransitions.CanTransition(FishingState.HandlingCatch, FishingState.Cooldown), "HandlingCatch→Cooldown");
            Ok(FsmTransitions.CanTransition(FishingState.Cooldown, FishingState.SelectingTarget), "Cooldown→SelectingTarget");
            Ok(FsmTransitions.CanTransition(FishingState.PreparingCast, FishingState.ErrorRecovery), "any active→ErrorRecovery");

            Ok(!FsmTransitions.CanTransition(FishingState.Idle, FishingState.Casting), "no skipping states");
            Ok(!FsmTransitions.CanTransition(FishingState.Cooldown, FishingState.Casting), "cooldown can't jump to casting");
            Ok(!FsmTransitions.CanTransition(FishingState.FishingMinigame, FishingState.SelectingTarget), "minigame must end first");
        }

        // ------------------------------------------------------------------ модели

        private static void ModelTests()
        {
            var t = new BubbleTarget("Forest", 42, 18, BubbleKind.Splash, 1000);
            Ok(t.Key == "Forest|42|18|Splash", "bubble key format");
            Ok(t.Equals(new BubbleTarget("Forest", 42, 18, BubbleKind.Splash, 2000)), "same spot equals ignoring time");
            Ok(!t.Equals(new BubbleTarget("Beach", 42, 18, BubbleKind.Splash, 2000)), "different location not equal");

            var frenzy = new BubbleTarget("Beach", 1, 2, BubbleKind.FishFrenzy, 0);
            Ok((frenzy.Kind & BubbleKind.FishFrenzy) != 0, "frenzy kind flag");
        }
    }
}
